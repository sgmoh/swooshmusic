import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Original user schema (keeping it as a reference)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Bot Status Schema
export const botStatus = pgTable("bot_status", {
  id: serial("id").primaryKey(),
  isOnline: boolean("is_online").notNull().default(true),
  startupTime: timestamp("startup_time").notNull().defaultNow(),
  serverCount: integer("server_count").notNull().default(0),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertBotStatusSchema = createInsertSchema(botStatus).omit({
  id: true,
});

export type InsertBotStatus = z.infer<typeof insertBotStatusSchema>;
export type BotStatus = typeof botStatus.$inferSelect;

// Command Usage Schema
export const commandUsage = pgTable("command_usage", {
  id: serial("id").primaryKey(),
  command: text("command").notNull(),
  server: text("server").notNull(),
  user: text("user").notNull(),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  success: boolean("success").notNull().default(true),
  errorMessage: text("error_message"),
});

export const insertCommandUsageSchema = createInsertSchema(commandUsage).omit({
  id: true,
});

export type InsertCommandUsage = z.infer<typeof insertCommandUsageSchema>;
export type CommandUsage = typeof commandUsage.$inferSelect;

// Currently Playing Track Schema
export const currentlyPlaying = pgTable("currently_playing", {
  id: serial("id").primaryKey(),
  trackName: text("track_name").notNull(),
  artistName: text("artist_name").notNull(),
  albumName: text("album_name"),
  albumArt: text("album_art"),
  duration: integer("duration").notNull(),
  progress: integer("progress").notNull().default(0),
  server: text("server"),
  channel: text("channel"),
  startedAt: timestamp("started_at").notNull().defaultNow(),
  isPlaying: boolean("is_playing").notNull().default(true),
});

export const insertCurrentlyPlayingSchema = createInsertSchema(currentlyPlaying).omit({
  id: true,
});

export type InsertCurrentlyPlaying = z.infer<typeof insertCurrentlyPlayingSchema>;
export type CurrentlyPlaying = typeof currentlyPlaying.$inferSelect;

// Spotify API Status Schema
export const apiStatus = pgTable("api_status", {
  id: serial("id").primaryKey(),
  service: text("service").notNull(), // "discord" or "spotify"
  requestCount: integer("request_count").notNull().default(0),
  requestLimit: integer("request_limit").notNull().default(0),
  resetTime: timestamp("reset_time"),
  lastStatus: integer("last_status"),
  lastUpdated: timestamp("last_updated").notNull().defaultNow(),
});

export const insertApiStatusSchema = createInsertSchema(apiStatus).omit({
  id: true,
});

export type InsertApiStatus = z.infer<typeof insertApiStatusSchema>;
export type ApiStatus = typeof apiStatus.$inferSelect;
