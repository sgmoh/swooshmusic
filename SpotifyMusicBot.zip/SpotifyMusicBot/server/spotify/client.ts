import SpotifyWebApi from 'spotify-web-api-node';
import { storage } from '../storage';

// Spotify credentials from environment variables
const SPOTIFY_CLIENT_ID = process.env.SPOTIFY_CLIENT_ID || '7ef9288b334a4b8995d335090e861201';
const SPOTIFY_CLIENT_SECRET = process.env.SPOTIFY_CLIENT_SECRET || 'bd3d5d65468948ec8efc2ead22f8fb6c';

// Initialize Spotify API client
const spotifyApi = new SpotifyWebApi({
  clientId: SPOTIFY_CLIENT_ID,
  clientSecret: SPOTIFY_CLIENT_SECRET
});

/**
 * Ensures that the Spotify API client has a valid access token
 */
async function ensureToken() {
  // Check if token is expired or not set
  if (!spotifyApi.getAccessToken()) {
    try {
      const data = await spotifyApi.clientCredentialsGrant();
      spotifyApi.setAccessToken(data.body.access_token);
      console.log('Spotify access token has been refreshed');
      
      // Update the reset time in API status
      await storage.updateApiStatus({
        service: 'spotify',
        resetTime: new Date(Date.now() + data.body.expires_in * 1000)
      });
    } catch (error) {
      console.error('Error obtaining Spotify access token:', error);
      throw new Error('Failed to authenticate with Spotify');
    }
  }
}

/**
 * Updates the API status tracking for Spotify requests
 * @param statusCode HTTP status code from response
 */
async function updateApiStatus(statusCode: number) {
  try {
    const currentStatus = await storage.getApiStatus('spotify');
    
    if (currentStatus) {
      await storage.updateApiStatus({
        service: 'spotify',
        requestCount: currentStatus.requestCount + 1,
        lastStatus: statusCode
      });
    }
  } catch (error) {
    console.error('Error updating Spotify API status:', error);
  }
}

/**
 * Search for tracks on Spotify
 * @param query Search query
 * @param limit Maximum number of results (default: 5)
 * @returns Promise with search results
 */
export async function searchTracks(query: string, limit: number = 5) {
  try {
    await ensureToken();
    
    const response = await spotifyApi.searchTracks(query, { limit });
    await updateApiStatus(200);
    
    return response.body.tracks?.items || [];
  } catch (error) {
    console.error('Error searching Spotify tracks:', error);
    await updateApiStatus(error.statusCode || 500);
    throw error;
  }
}

/**
 * Get a track by its Spotify ID or URL
 * @param trackId Spotify track ID or URL
 * @returns Promise with track details
 */
export async function getTrack(trackId: string) {
  try {
    // Extract track ID if a full URL was provided
    if (trackId.includes('spotify.com/track/')) {
      trackId = trackId.split('track/')[1].split('?')[0];
    }
    
    await ensureToken();
    
    const response = await spotifyApi.getTrack(trackId);
    await updateApiStatus(200);
    
    return response.body;
  } catch (error) {
    console.error('Error getting Spotify track:', error);
    await updateApiStatus(error.statusCode || 500);
    throw error;
  }
}

export default spotifyApi;
