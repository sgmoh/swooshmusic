import { 
  users, type User, type InsertUser,
  botStatus, type BotStatus, type InsertBotStatus,
  commandUsage, type CommandUsage, type InsertCommandUsage,
  currentlyPlaying, type CurrentlyPlaying, type InsertCurrentlyPlaying,
  apiStatus, type ApiStatus, type InsertApiStatus
} from "@shared/schema";

// Interface with CRUD methods for all data models
export interface IStorage {
  // User methods (keeping original ones)
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Bot status methods
  getBotStatus(): Promise<BotStatus | undefined>;
  updateBotStatus(status: Partial<InsertBotStatus>): Promise<BotStatus>;
  
  // Command usage methods
  getCommandUsage(limit?: number): Promise<CommandUsage[]>;
  createCommandUsage(usage: InsertCommandUsage): Promise<CommandUsage>;
  
  // Currently playing methods
  getCurrentlyPlaying(): Promise<CurrentlyPlaying | undefined>;
  updateCurrentlyPlaying(track: InsertCurrentlyPlaying): Promise<CurrentlyPlaying>;
  
  // API status methods
  getApiStatus(service: string): Promise<ApiStatus | undefined>;
  updateApiStatus(status: Partial<InsertApiStatus> & { service: string }): Promise<ApiStatus>;
}

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private botStatusRecord: BotStatus | undefined;
  private commandUsageRecords: CommandUsage[];
  private currentlyPlayingRecord: CurrentlyPlaying | undefined;
  private apiStatusRecords: Map<string, ApiStatus>;
  
  currentId: number;
  commandId: number;
  apiStatusId: number;

  constructor() {
    this.users = new Map();
    this.commandUsageRecords = [];
    this.apiStatusRecords = new Map();
    this.currentId = 1;
    this.commandId = 1;
    this.apiStatusId = 1;
    
    // Initialize with default values
    this.botStatusRecord = {
      id: 1,
      isOnline: true,
      startupTime: new Date(),
      serverCount: 0,
      lastUpdated: new Date()
    };
    
    // Initialize API status for Discord and Spotify
    this.apiStatusRecords.set("discord", {
      id: this.apiStatusId++,
      service: "discord",
      requestCount: 0,
      requestLimit: 120,
      resetTime: new Date(Date.now() + 60000), // 1 minute from now
      lastStatus: 200,
      lastUpdated: new Date()
    });
    
    this.apiStatusRecords.set("spotify", {
      id: this.apiStatusId++,
      service: "spotify",
      requestCount: 0,
      requestLimit: 150,
      resetTime: new Date(Date.now() + 120000), // 2 minutes from now
      lastStatus: 200,
      lastUpdated: new Date()
    });
  }

  // User methods (keeping original ones)
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }
  
  // Bot status methods
  async getBotStatus(): Promise<BotStatus | undefined> {
    return this.botStatusRecord;
  }
  
  async updateBotStatus(status: Partial<InsertBotStatus>): Promise<BotStatus> {
    if (!this.botStatusRecord) {
      this.botStatusRecord = {
        id: 1,
        isOnline: status.isOnline ?? true,
        startupTime: status.startupTime ?? new Date(),
        serverCount: status.serverCount ?? 0,
        lastUpdated: new Date()
      };
    } else {
      this.botStatusRecord = {
        ...this.botStatusRecord,
        ...status,
        lastUpdated: new Date()
      };
    }
    return this.botStatusRecord;
  }
  
  // Command usage methods
  async getCommandUsage(limit: number = 100): Promise<CommandUsage[]> {
    return this.commandUsageRecords
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime())
      .slice(0, limit);
  }
  
  async createCommandUsage(usage: InsertCommandUsage): Promise<CommandUsage> {
    const id = this.commandId++;
    const record: CommandUsage = { ...usage, id };
    this.commandUsageRecords.push(record);
    return record;
  }
  
  // Currently playing methods
  async getCurrentlyPlaying(): Promise<CurrentlyPlaying | undefined> {
    return this.currentlyPlayingRecord;
  }
  
  async updateCurrentlyPlaying(track: InsertCurrentlyPlaying): Promise<CurrentlyPlaying> {
    this.currentlyPlayingRecord = {
      id: 1,
      ...track
    };
    return this.currentlyPlayingRecord;
  }
  
  // API status methods
  async getApiStatus(service: string): Promise<ApiStatus | undefined> {
    return this.apiStatusRecords.get(service);
  }
  
  async updateApiStatus(status: Partial<InsertApiStatus> & { service: string }): Promise<ApiStatus> {
    const existing = this.apiStatusRecords.get(status.service);
    
    if (!existing) {
      const newStatus: ApiStatus = {
        id: this.apiStatusId++,
        service: status.service,
        requestCount: status.requestCount ?? 0,
        requestLimit: status.requestLimit ?? 0,
        resetTime: status.resetTime,
        lastStatus: status.lastStatus,
        lastUpdated: new Date()
      };
      this.apiStatusRecords.set(status.service, newStatus);
      return newStatus;
    }
    
    const updated: ApiStatus = {
      ...existing,
      ...status,
      lastUpdated: new Date()
    };
    
    this.apiStatusRecords.set(status.service, updated);
    return updated;
  }
}

export const storage = new MemStorage();
