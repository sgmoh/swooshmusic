import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { startBot } from "./discord/bot";
import { formatUptime, formatTimeUntil, formatRelativeTime, formatTime, formatTrackDuration, calculateProgressPercentage } from "./utils";

export async function registerRoutes(app: Express): Promise<Server> {
  // Start the Discord bot when the server starts
  await startBot();
  
  // Setup API routes
  const apiRouter = express.Router();
  
  // Get bot status
  apiRouter.get('/status', async (req, res) => {
    try {
      const status = await storage.getBotStatus();
      
      if (!status) {
        return res.status(404).json({ message: 'Bot status not found' });
      }
      
      const botStatus = {
        isOnline: status.isOnline,
        uptime: formatUptime(status.startupTime),
        serverCount: status.serverCount,
        startupTime: status.startupTime,
        lastUpdated: status.lastUpdated
      };
      
      res.json(botStatus);
    } catch (error) {
      console.error('Error fetching bot status:', error);
      res.status(500).json({ message: 'Failed to fetch bot status' });
    }
  });
  
  // Get currently playing track
  apiRouter.get('/playing', async (req, res) => {
    try {
      const track = await storage.getCurrentlyPlaying();
      
      if (!track) {
        return res.status(404).json({ message: 'No track currently playing' });
      }
      
      const progress = calculateProgressPercentage(track.startedAt, track.duration, track.isPlaying);
      
      const currentTrack = {
        ...track,
        progressPercent: progress,
        formattedProgress: formatTrackDuration(Math.floor(track.duration * (progress / 100))),
        formattedDuration: formatTrackDuration(track.duration)
      };
      
      res.json(currentTrack);
    } catch (error) {
      console.error('Error fetching currently playing track:', error);
      res.status(500).json({ message: 'Failed to fetch currently playing track' });
    }
  });
  
  // Get command usage statistics
  apiRouter.get('/commands', async (req, res) => {
    try {
      const limit = req.query.limit ? parseInt(req.query.limit as string) : 5;
      const commands = await storage.getCommandUsage(limit);
      
      // Format time for display
      const formattedCommands = commands.map(cmd => ({
        ...cmd,
        relativeTime: formatRelativeTime(cmd.timestamp),
        formattedTime: formatTime(cmd.timestamp)
      }));
      
      res.json(formattedCommands);
    } catch (error) {
      console.error('Error fetching command usage:', error);
      res.status(500).json({ message: 'Failed to fetch command usage' });
    }
  });
  
  // Get API status
  apiRouter.get('/api-status', async (req, res) => {
    try {
      const discordStatus = await storage.getApiStatus('discord');
      const spotifyStatus = await storage.getApiStatus('spotify');
      
      if (!discordStatus || !spotifyStatus) {
        return res.status(404).json({ message: 'API status not found' });
      }
      
      const apiStatus = {
        discord: {
          ...discordStatus,
          resetTimeFormatted: discordStatus.resetTime ? formatTimeUntil(discordStatus.resetTime) : 'N/A'
        },
        spotify: {
          ...spotifyStatus,
          resetTimeFormatted: spotifyStatus.resetTime ? formatTimeUntil(spotifyStatus.resetTime) : 'N/A'
        }
      };
      
      res.json(apiStatus);
    } catch (error) {
      console.error('Error fetching API status:', error);
      res.status(500).json({ message: 'Failed to fetch API status' });
    }
  });
  
  // Get usage statistics
  apiRouter.get('/stats', async (req, res) => {
    try {
      const commands = await storage.getCommandUsage();
      const status = await storage.getBotStatus();
      
      if (!status) {
        return res.status(404).json({ message: 'Bot status not found' });
      }
      
      // Calculate some basic stats
      const totalCommands = commands.length;
      const successfulCommands = commands.filter(cmd => cmd.success).length;
      const commandsLast7Days = commands.filter(cmd => {
        const sevenDaysAgo = new Date();
        sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
        return cmd.timestamp >= sevenDaysAgo;
      }).length;
      
      // Count unique users
      const uniqueUsers = new Set(commands.map(cmd => cmd.user)).size;
      
      const stats = {
        serverCount: status.serverCount,
        totalCommands,
        successfulCommands,
        commandsLast7Days,
        uniqueUsers
      };
      
      res.json(stats);
    } catch (error) {
      console.error('Error fetching stats:', error);
      res.status(500).json({ message: 'Failed to fetch stats' });
    }
  });
  
  // Mount API routes
  app.use('/api', apiRouter);

  const httpServer = createServer(app);
  
  return httpServer;
}
