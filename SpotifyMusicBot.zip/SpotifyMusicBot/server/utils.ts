import { differenceInSeconds, differenceInMinutes, differenceInHours, differenceInDays } from 'date-fns';

/**
 * Formats uptime from a start date to a human-readable string
 * @param startTime The start time
 * @returns Formatted uptime string like "5d 12h 34m"
 */
export function formatUptime(startTime: Date): string {
  const now = new Date();
  const days = differenceInDays(now, startTime);
  const hours = differenceInHours(now, startTime) % 24;
  const minutes = differenceInMinutes(now, startTime) % 60;
  
  return `${days}d ${hours}h ${minutes}m`;
}

/**
 * Formats time until a future date (for API rate limit reset)
 * @param resetTime The future reset time
 * @returns Formatted time string like "2m 30s" or "44s"
 */
export function formatTimeUntil(resetTime: Date): string {
  const now = new Date();
  if (resetTime < now) return "0s";
  
  const minutes = differenceInMinutes(resetTime, now);
  const seconds = differenceInSeconds(resetTime, now) % 60;
  
  if (minutes > 0) {
    return `${minutes}m ${seconds}s`;
  }
  return `${seconds}s`;
}

/**
 * Formats a relative time string for activity logs
 * @param timestamp The timestamp to format
 * @returns Formatted time string like "2m ago" or "1h ago"
 */
export function formatRelativeTime(timestamp: Date): string {
  const now = new Date();
  const minutesAgo = differenceInMinutes(now, timestamp);
  const hoursAgo = differenceInHours(now, timestamp);
  
  if (hoursAgo >= 1) {
    return `${hoursAgo}h ago`;
  }
  return `${minutesAgo}m ago`;
}

/**
 * Formats a time string for activity logs (12-hour format)
 * @param timestamp The timestamp to format
 * @returns Formatted time string like "12:45 PM"
 */
export function formatTime(timestamp: Date): string {
  return timestamp.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}

/**
 * Format the duration of a track in MM:SS format
 * @param durationMs Duration in milliseconds
 * @returns Formatted duration string like "3:45"
 */
export function formatTrackDuration(durationMs: number): string {
  const totalSeconds = Math.floor(durationMs / 1000);
  const minutes = Math.floor(totalSeconds / 60);
  const seconds = totalSeconds % 60;
  
  return `${minutes}:${seconds.toString().padStart(2, '0')}`;
}

/**
 * Format the current progress of a track in MM:SS format
 * @param startedAt When the track started playing
 * @param durationMs Total duration in milliseconds
 * @param isPlaying Whether the track is currently playing
 * @returns Formatted progress string like "1:23"
 */
export function formatTrackProgress(startedAt: Date, durationMs: number, isPlaying: boolean): string {
  if (!isPlaying) {
    // If paused, return the stored progress
    return formatTrackDuration(0);
  }
  
  const elapsedMs = Math.min(Date.now() - startedAt.getTime(), durationMs);
  return formatTrackDuration(elapsedMs);
}

/**
 * Calculate the percentage of track progress
 * @param startedAt When the track started playing
 * @param durationMs Total duration in milliseconds
 * @param isPlaying Whether the track is currently playing
 * @returns Progress percentage between 0 and 100
 */
export function calculateProgressPercentage(startedAt: Date, durationMs: number, isPlaying: boolean): number {
  if (!isPlaying) return 0;
  
  const elapsedMs = Date.now() - startedAt.getTime();
  return Math.min(Math.floor((elapsedMs / durationMs) * 100), 100);
}
