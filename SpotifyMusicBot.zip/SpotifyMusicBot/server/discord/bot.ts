import { Client, Events, GatewayIntentBits } from 'discord.js';
import { MusicCommandHandler } from './music';
import { storage } from '../storage';

// Discord credentials from environment variables
const DISCORD_TOKEN = process.env.DISCORD_TOKEN || 'MTM2MTY4NDk3MjE2MzAzOTMxMg.GfhKeC.ORN_QnyZ-2cstAbY94paFoyrKxll8jh444I_wE';

// Initialize Discord client
const client = new Client({ 
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates
  ]
});

// Initialize music command handler
const musicHandler = new MusicCommandHandler(client);

// Set up event listeners
client.once(Events.ClientReady, (readyClient) => {
  console.log(`Ready! Logged in as ${readyClient.user.tag}`);
  
  // Update bot status in storage
  storage.updateBotStatus({
    isOnline: true,
    startupTime: new Date(),
    serverCount: readyClient.guilds.cache.size
  });
  
  // Set bot activity
  readyClient.user.setActivity('.music help', { type: 2 }); // Type 2 is "Listening to"
});

// Message event listener
client.on(Events.MessageCreate, async (message) => {
  // Ignore bot messages
  if (message.author.bot) return;
  
  // Handle .music commands
  if (message.content.startsWith('.music')) {
    try {
      // Update Discord API status
      const discordStatus = await storage.getApiStatus('discord');
      if (discordStatus) {
        await storage.updateApiStatus({
          service: 'discord',
          requestCount: discordStatus.requestCount + 1,
          lastStatus: 200
        });
      }
      
      // Handle the music command
      await musicHandler.handleCommand(message);
    } catch (error) {
      console.error('Error processing message:', error);
      
      // Update API status with error
      await storage.updateApiStatus({
        service: 'discord',
        lastStatus: 500
      });
      
      // Reply with error
      message.reply('An error occurred while processing your command');
    }
  }
});

// Guild create/delete events to track server count
client.on(Events.GuildCreate, async () => {
  const status = await storage.getBotStatus();
  if (status) {
    await storage.updateBotStatus({
      serverCount: client.guilds.cache.size
    });
  }
});

client.on(Events.GuildDelete, async () => {
  const status = await storage.getBotStatus();
  if (status) {
    await storage.updateBotStatus({
      serverCount: client.guilds.cache.size
    });
  }
});

// Error handler
client.on(Events.Error, (error) => {
  console.error('Discord client error:', error);
});

/**
 * Start the Discord bot
 */
export async function startBot() {
  try {
    await client.login(DISCORD_TOKEN);
    console.log('Discord bot started');
    return true;
  } catch (error) {
    console.error('Failed to start Discord bot:', error);
    
    // Update bot status to offline
    await storage.updateBotStatus({
      isOnline: false
    });
    
    return false;
  }
}

export default client;
