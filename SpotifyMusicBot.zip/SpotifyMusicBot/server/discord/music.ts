import { Client, Message, EmbedBuilder, VoiceBasedChannel } from 'discord.js';
import { 
  joinVoiceChannel, 
  createAudioPlayer, 
  createAudioResource, 
  AudioPlayerStatus,
  VoiceConnectionStatus,
  entersState,
  getVoiceConnection,
  NoSubscriberBehavior,
  StreamType
} from '@discordjs/voice';
import play from 'play-dl';
import { searchTracks, getTrack } from '../spotify/client';
import { storage } from '../storage';
import { formatTrackDuration } from '../utils';

// Configure play-dl with better rate limiting
play.setToken({
  youtube: {
    cookie: ''  // No cookie needed for basic YouTube operations
  }
});

// Music command handler for Discord bot
export class MusicCommandHandler {
  private client: Client;
  
  constructor(client: Client) {
    this.client = client;
  }
  
  /**
   * Handle a .music command from Discord
   * @param message The Discord message containing the command
   */
  async handleCommand(message: Message) {
    try {
      const content = message.content.trim();
      const args = content.slice('.music '.length).trim().split(/\s+/);
      const subCommand = args.shift()?.toLowerCase() || 'help';
      
      // Log the command
      await storage.createCommandUsage({
        command: `.music ${subCommand} ${args.join(' ')}`.trim(),
        server: message.guild?.name || 'DM',
        user: message.author.username,
        timestamp: new Date(),
        success: true
      });
      
      // Handle different subcommands
      switch (subCommand) {
        case 'search':
          await this.handleSearch(message, args.join(' '));
          break;
        case 'play':
          await this.handlePlay(message, args.join(' '));
          break;
        case 'queue':
          await this.handleQueue(message);
          break;
        case 'controls':
          await this.handleControls(message, args[0]);
          break;
        case 'help':
        default:
          await this.handleHelp(message);
          break;
      }
    } catch (error: any) {
      console.error('Error handling music command:', error);
      
      // Log the failed command
      await storage.createCommandUsage({
        command: message.content,
        server: message.guild?.name || 'DM',
        user: message.author.username,
        timestamp: new Date(),
        success: false,
        errorMessage: error.message
      });
      
      // Send error message
      await message.reply({
        embeds: [
          new EmbedBuilder()
            .setColor('#F04747')
            .setTitle('Error')
            .setDescription(`Failed to process command: ${error.message}`)
        ]
      });
    }
  }
  
  /**
   * Handle the .music search command
   */
  private async handleSearch(message: Message, query: string) {
    if (!query) {
      await message.reply('Please provide a search query. Example: `.music search Starlight`');
      return;
    }
    
    const results = await searchTracks(query);
    
    if (results.length === 0) {
      await message.reply(`No results found for "${query}"`);
      return;
    }
    
    const embed = new EmbedBuilder()
      .setColor('#1DB954')
      .setTitle(`Search Results for "${query}"`)
      .setDescription(
        results.map((track: any, index: number) => 
          `${index + 1}. **${track.name}** by ${track.artists.map((a: any) => a.name).join(', ')} ` +
          `[${formatTrackDuration(track.duration_ms)}]`
        ).join('\n\n')
      )
      .setFooter({ text: 'Play a song using .music play <song name> or full Spotify URL' });
    
    await message.reply({ embeds: [embed] });
  }
  
  /**
   * Handle the .music play command
   */
  private async handlePlay(message: Message, query: string) {
    if (!query) {
      await message.reply('Please provide a song name or Spotify URL. Example: `.music play Starlight`');
      return;
    }
    
    // Check if user is in a voice channel
    const voiceChannel = message.member?.voice.channel;
    if (!voiceChannel) {
      await message.reply('You need to be in a voice channel to play music!');
      return;
    }
    
    try {
      // Reply with loading message
      const loadingMsg = await message.reply('🔍 Searching track and preparing voice connection...');
      
      let track;
      
      // Check if the query is a Spotify URL
      if (query.includes('spotify.com/track/')) {
        track = await getTrack(query);
      } else {
        // Otherwise search for the track
        const results = await searchTracks(query);
        
        if (results.length === 0) {
          await loadingMsg.edit(`No results found for "${query}"`);
          return;
        }
        
        track = results[0];
      }
      
      // Get voice channel information for display
      const voiceChannelName = voiceChannel.name;
      const guildName = message.guild?.name || 'Unknown Server';
      
      // Connect to the voice channel
      const connection = joinVoiceChannel({
        channelId: voiceChannel.id,
        guildId: voiceChannel.guild.id,
        adapterCreator: voiceChannel.guild.voiceAdapterCreator,
      });
      
      // Create an audio player with proper configuration
      const player = createAudioPlayer({
        behaviors: {
          noSubscriber: NoSubscriberBehavior.Play // Continue playing even without subscribers
        }
      });
      connection.subscribe(player);
      
      // Handle connection ready
      connection.on(VoiceConnectionStatus.Ready, async () => {
        try {
          await loadingMsg.edit(`Connected to ${voiceChannelName} and searching for track...`);
          
          // Search for the song on YouTube (using play-dl)
          const searchString = `${track.name} ${track.artists.map((a: any) => a.name).join(' ')}`;
          console.log(`Searching for: ${searchString}`);
          
          await loadingMsg.edit(`Searching for "${searchString}"...`);
          const searchResult = await play.search(searchString, { limit: 3 });
          
          if (!searchResult || searchResult.length === 0) {
            await loadingMsg.edit(`Could not find a playable source for "${track.name}"`);
            connection.destroy();
            return;
          }
          
          const songInfo = searchResult[0];
          console.log(`Found song: ${songInfo.title} (${songInfo.url})`);
          
          // Get stream with better error handling
          await loadingMsg.edit(`Preparing audio stream...`);
          
          try {
            console.log("Getting stream...");
            
            // Simple attempt to get stream with basic retry
            await loadingMsg.edit(`Getting audio stream...`);
            
            // Add a small delay before requesting to avoid rate limits
            await new Promise(resolve => setTimeout(resolve, 500));
            
            // Try to get the stream
            console.log(`Attempting to stream audio from: ${songInfo.url}`);
            const stream = await play.stream(songInfo.url);
            
            if (!stream) {
              throw new Error("Failed to get audio stream");
            }
            
            console.log("Creating audio resource");
            // Create resource with inline volume to ensure proper playback
            const resource = createAudioResource(stream.stream, {
              inputType: stream.type,
              inlineVolume: true
            });
            
            // Set volume to 100%
            if (resource.volume) {
              resource.volume.setVolume(1);
            }
            
            // Add listener for errors before playing
            player.on('error', (error: any) => {
              console.error('Audio player error:', error);
              loadingMsg.edit(`Error playing audio: ${error.message}`).catch(console.error);
            });
            
            // Log state transitions
            player.on(AudioPlayerStatus.Playing, () => {
              console.log('Audio player is playing');
              loadingMsg.edit(`Now playing: ${track.name} in ${voiceChannelName}`).catch(console.error);
            });
            
            // Add idle transition to detect when song ends
            player.on(AudioPlayerStatus.Idle, async () => {
              console.log('Audio player is idle');
              // Track finished playing
              const currentTrack = await storage.getCurrentlyPlaying();
              if (currentTrack) {
                await storage.updateCurrentlyPlaying({
                  ...currentTrack,
                  isPlaying: false
                });
              }
              connection.destroy();
            });
            
            // Update currently playing track in storage
            await storage.updateCurrentlyPlaying({
              trackName: track.name,
              artistName: track.artists.map((a: any) => a.name).join(', '),
              albumName: track.album.name,
              albumArt: track.album.images[0]?.url,
              duration: track.duration_ms,
              progress: 0,
              server: guildName,
              channel: voiceChannelName,
              startedAt: new Date(),
              isPlaying: true
            });
            
            // Play the track after setting everything up
            player.play(resource);
            
            // Send confirmation to Discord
            const embed = new EmbedBuilder()
              .setColor('#1DB954')
              .setTitle('Now Playing in Voice Channel')
              .setDescription(`**${track.name}**\nBy ${track.artists.map((a: any) => a.name).join(', ')}`)
              .setThumbnail(track.album.images[0]?.url)
              .addFields(
                { name: 'Album', value: track.album.name, inline: true },
                { name: 'Duration', value: formatTrackDuration(track.duration_ms), inline: true },
                { name: 'Voice Channel', value: voiceChannelName, inline: true }
              )
              .setFooter({ text: `Requested by ${message.author.username} in ${guildName}` });
            
            await loadingMsg.edit({ content: null, embeds: [embed] });
            
          } catch (streamError: any) {
            console.error('Error setting up stream:', streamError);
            await loadingMsg.edit(`Error setting up audio stream: ${streamError.message}`);
            connection.destroy();
          }
          
        } catch (err: any) {
          console.error('Error playing track:', err);
          await loadingMsg.edit(`Error playing track: ${err.message}`);
          connection.destroy();
        }
      });
      
      // Handle connection errors
      connection.on(VoiceConnectionStatus.Disconnected, async () => {
        try {
          await entersState(connection, VoiceConnectionStatus.Signalling, 5_000);
          await entersState(connection, VoiceConnectionStatus.Connecting, 5_000);
        } catch (error: any) {
          connection.destroy();
          const currentTrack = await storage.getCurrentlyPlaying();
          if (currentTrack) {
            await storage.updateCurrentlyPlaying({
              ...currentTrack,
              isPlaying: false
            });
          }
        }
      });
      
    } catch (error: any) {
      console.error('Error in voice connection:', error);
      await message.reply(`Error connecting to voice channel: ${error.message}`);
    }
  }
  
  /**
   * Handle the .music queue command
   */
  private async handleQueue(message: Message) {
    const currentTrack = await storage.getCurrentlyPlaying();
    
    if (!currentTrack) {
      await message.reply('No music is currently playing.');
      return;
    }
    
    const embed = new EmbedBuilder()
      .setColor('#1DB954')
      .setTitle('Current Queue')
      .setDescription(
        `**Now Playing:**\n${currentTrack.trackName} by ${currentTrack.artistName}\n\n` +
        `**Up Next:**\nNo songs in queue.` // For simplicity, we're not implementing a real queue system
      )
      .setThumbnail(currentTrack.albumArt)
      .setFooter({ text: `Playing in ${currentTrack.server} / ${currentTrack.channel}` });
    
    await message.reply({ embeds: [embed] });
  }
  
  /**
   * Handle the .music controls command
   */
  private async handleControls(message: Message, control: string) {
    const currentTrack = await storage.getCurrentlyPlaying();
    
    if (!currentTrack) {
      await message.reply('No music is currently playing.');
      return;
    }
    
    // Check if user is in a voice channel
    const voiceChannel = message.member?.voice.channel;
    if (!voiceChannel) {
      await message.reply('You need to be in a voice channel to control music playback!');
      return;
    }
    
    // Check if bot is in a voice channel on this server
    const guild = message.guild;
    if (!guild) {
      await message.reply('This command can only be used in a server.');
      return;
    }
    
    const connection = getVoiceConnection(guild.id);
    if (!connection) {
      await message.reply('Bot is not currently in a voice channel on this server.');
      return;
    }
    
    let statusMessage = '';
    
    switch (control?.toLowerCase()) {
      case 'pause':
        try {
          // Since we don't have direct access to the player through the connection
          // We'll just update the state and handle it via the UI for now
          await storage.updateCurrentlyPlaying({
            ...currentTrack,
            isPlaying: false
          });
          statusMessage = `⏸️ Paused **${currentTrack.trackName}**`;
        } catch (err: any) {
          statusMessage = `Error pausing playback: ${err.message}`;
        }
        break;
      
      case 'resume':
        try {
          await storage.updateCurrentlyPlaying({
            ...currentTrack,
            isPlaying: true,
            startedAt: new Date() // Reset the start time
          });
          statusMessage = `▶️ Resumed **${currentTrack.trackName}**`;
        } catch (err: any) {
          statusMessage = `Error resuming playback: ${err.message}`;
        }
        break;
      
      case 'skip':
        try {
          // For skip/stop, we'll destroy the connection which effectively stops playback
          connection.destroy();
          await storage.updateCurrentlyPlaying({
            ...currentTrack,
            isPlaying: false
          });
          statusMessage = `⏭️ Skipped **${currentTrack.trackName}**`;
        } catch (err: any) {
          statusMessage = `Error skipping track: ${err.message}`;
        }
        break;
      
      case 'stop':
        try {
          connection.destroy();
          await storage.updateCurrentlyPlaying({
            ...currentTrack,
            isPlaying: false
          });
          statusMessage = `⏹️ Stopped playback`;
        } catch (err: any) {
          statusMessage = `Error stopping playback: ${err.message}`;
        }
        break;
      
      default:
        statusMessage = 'Available controls: `.music controls pause|resume|skip|stop`';
        break;
    }
    
    await message.reply(statusMessage);
  }
  
  /**
   * Handle the .music help command
   */
  private async handleHelp(message: Message) {
    const embed = new EmbedBuilder()
      .setColor('#7289DA')
      .setTitle('Music Bot Commands')
      .setDescription('Here are the available music commands:')
      .addFields(
        { 
          name: '.music search <song name>', 
          value: 'Search for songs on Spotify', 
          inline: false 
        },
        { 
          name: '.music play <song name or Spotify URL>', 
          value: 'Play a song from Spotify', 
          inline: false 
        },
        { 
          name: '.music queue', 
          value: 'View current song queue', 
          inline: false 
        },
        { 
          name: '.music controls <action>', 
          value: 'Control playback (pause, resume, skip, stop)', 
          inline: false 
        }
      )
      .setFooter({ text: 'Music Bot powered by Spotify' });
    
    await message.reply({ embeds: [embed] });
  }
}