package com.swooshbot.discordbot.commands;

import com.sedmelluq.discord.lavaplayer.player.AudioPlayer;
import com.swooshbot.discordbot.audio.GuildMusicManager;
import com.swooshbot.discordbot.audio.PlayerManager;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.GuildVoiceState;
import net.dv8tion.jda.api.entities.Member;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.awt.Color;

/**
 * Command to control music playback
 */
public class ControlsCommand implements Command {
    private static final Logger logger = LoggerFactory.getLogger(ControlsCommand.class);
    
    private final PlayerManager playerManager;
    
    /**
     * Create a new controls command
     * @param playerManager Audio player manager
     */
    public ControlsCommand(PlayerManager playerManager) {
        this.playerManager = playerManager;
    }
    
    @Override
    public String getName() {
        return "controls";
    }
    
    @Override
    public String getDescription() {
        return "Control music playback (pause, resume, skip, stop)";
    }
    
    @Override
    public String getUsage() {
        return "controls <pause|resume|skip|stop>";
    }
    
    @Override
    public void execute(MessageReceivedEvent event, String args) {
        if (args == null || args.trim().isEmpty()) {
            event.getChannel().sendMessage("❌ Please specify a control action. Use `controls <pause|resume|skip|stop>`").queue();
            return;
        }
        
        Member member = event.getMember();
        if (member == null) {
            event.getChannel().sendMessage("❌ This command can only be used in a server").queue();
            return;
        }
        
        // Check if the user is in a voice channel
        GuildVoiceState voiceState = member.getVoiceState();
        if (voiceState == null || !voiceState.inAudioChannel()) {
            event.getChannel().sendMessage("❌ You need to be in a voice channel to control playback!").queue();
            return;
        }
        
        // Get guild music manager
        GuildMusicManager musicManager = playerManager.getGuildMusicManager(event.getGuild().getId());
        AudioPlayer player = musicManager.getAudioPlayer();
        
        // Check if anything is playing
        if (player.getPlayingTrack() == null) {
            event.getChannel().sendMessage("❌ Nothing is currently playing!").queue();
            return;
        }
        
        // Parse control action
        String action = args.trim().toLowerCase();
        
        switch (action) {
            case "pause":
                handlePause(event, player);
                break;
            case "resume":
                handleResume(event, player);
                break;
            case "skip":
                handleSkip(event, musicManager);
                break;
            case "stop":
                handleStop(event, musicManager);
                break;
            default:
                event.getChannel().sendMessage("❌ Unknown control action. Use `pause`, `resume`, `skip`, or `stop`").queue();
                break;
        }
    }
    
    /**
     * Handle pause action
     * @param event Message event
     * @param player Audio player
     */
    private void handlePause(MessageReceivedEvent event, AudioPlayer player) {
        if (player.isPaused()) {
            event.getChannel().sendMessage("⚠️ Playback is already paused!").queue();
            return;
        }
        
        player.setPaused(true);
        
        EmbedBuilder embed = new EmbedBuilder();
        embed.setColor(new Color(244, 174, 59)); // Orange
        embed.setTitle("⏸️ Playback Paused");
        embed.setDescription("Paused **" + player.getPlayingTrack().getInfo().title + "**");
        embed.setFooter("Use .music controls resume to continue playback");
        
        event.getChannel().sendMessageEmbeds(embed.build()).queue();
        logger.info("Paused playback in guild {}", event.getGuild().getId());
    }
    
    /**
     * Handle resume action
     * @param event Message event
     * @param player Audio player
     */
    private void handleResume(MessageReceivedEvent event, AudioPlayer player) {
        if (!player.isPaused()) {
            event.getChannel().sendMessage("⚠️ Playback is already playing!").queue();
            return;
        }
        
        player.setPaused(false);
        
        EmbedBuilder embed = new EmbedBuilder();
        embed.setColor(new Color(30, 215, 96)); // Spotify green
        embed.setTitle("▶️ Playback Resumed");
        embed.setDescription("Resumed **" + player.getPlayingTrack().getInfo().title + "**");
        
        event.getChannel().sendMessageEmbeds(embed.build()).queue();
        logger.info("Resumed playback in guild {}", event.getGuild().getId());
    }
    
    /**
     * Handle skip action
     * @param event Message event
     * @param musicManager Guild music manager
     */
    private void handleSkip(MessageReceivedEvent event, GuildMusicManager musicManager) {
        String currentTrackName = musicManager.getAudioPlayer().getPlayingTrack().getInfo().title;
        boolean hasNextTrack = musicManager.getTrackScheduler().skipTrack();
        
        EmbedBuilder embed = new EmbedBuilder();
        
        if (hasNextTrack) {
            String nextTrackName = musicManager.getAudioPlayer().getPlayingTrack().getInfo().title;
            
            embed.setColor(new Color(30, 215, 96)); // Spotify green
            embed.setTitle("⏭️ Track Skipped");
            embed.setDescription("Skipped **" + currentTrackName + "**");
            embed.addField("Now Playing", nextTrackName, false);
        } else {
            embed.setColor(new Color(244, 67, 54)); // Red
            embed.setTitle("⏭️ Track Skipped");
            embed.setDescription("Skipped **" + currentTrackName + "**");
            embed.addField("Queue", "No more tracks in the queue", false);
        }
        
        event.getChannel().sendMessageEmbeds(embed.build()).queue();
        logger.info("Skipped track in guild {}", event.getGuild().getId());
    }
    
    /**
     * Handle stop action
     * @param event Message event
     * @param musicManager Guild music manager
     */
    private void handleStop(MessageReceivedEvent event, GuildMusicManager musicManager) {
        String currentTrackName = musicManager.getAudioPlayer().getPlayingTrack().getInfo().title;
        
        // Stop playback and clear queue
        musicManager.getTrackScheduler().stop();
        
        // Leave voice channel
        event.getGuild().getAudioManager().closeAudioConnection();
        
        EmbedBuilder embed = new EmbedBuilder();
        embed.setColor(new Color(244, 67, 54)); // Red
        embed.setTitle("⏹️ Playback Stopped");
        embed.setDescription("Stopped playing **" + currentTrackName + "**");
        embed.addField("Queue", "Queue has been cleared", false);
        
        event.getChannel().sendMessageEmbeds(embed.build()).queue();
        logger.info("Stopped playback in guild {}", event.getGuild().getId());
    }
}