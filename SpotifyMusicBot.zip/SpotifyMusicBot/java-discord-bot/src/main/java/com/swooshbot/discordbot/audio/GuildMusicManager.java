package com.swooshbot.discordbot.audio;

import com.sedmelluq.discord.lavaplayer.player.AudioPlayer;
import com.sedmelluq.discord.lavaplayer.player.AudioPlayerManager;

/**
 * Music manager for a guild
 */
public class GuildMusicManager {
    private final AudioPlayer audioPlayer;
    private final TrackScheduler trackScheduler;
    private final AudioPlayerSendHandler sendHandler;
    
    /**
     * Create a new guild music manager
     * @param manager Audio player manager
     */
    public GuildMusicManager(AudioPlayerManager manager) {
        // Create audio player
        this.audioPlayer = manager.createPlayer();
        
        // Create track scheduler
        this.trackScheduler = new TrackScheduler(audioPlayer);
        this.audioPlayer.addListener(trackScheduler);
        
        // Create send handler
        this.sendHandler = new AudioPlayerSendHandler(audioPlayer);
    }
    
    /**
     * Get the audio player
     * @return Audio player
     */
    public AudioPlayer getAudioPlayer() {
        return audioPlayer;
    }
    
    /**
     * Get the track scheduler
     * @return Track scheduler
     */
    public TrackScheduler getTrackScheduler() {
        return trackScheduler;
    }
    
    /**
     * Get the send handler
     * @return Send handler
     */
    public AudioPlayerSendHandler getSendHandler() {
        return sendHandler;
    }
}