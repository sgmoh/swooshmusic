package com.swooshbot.discordbot.spotify;

import com.swooshbot.discordbot.config.ConfigLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import se.michaelthelin.spotify.SpotifyApi;
import se.michaelthelin.spotify.exceptions.SpotifyWebApiException;
import se.michaelthelin.spotify.model_objects.credentials.ClientCredentials;
import se.michaelthelin.spotify.model_objects.specification.Paging;
import se.michaelthelin.spotify.model_objects.specification.Track;
import se.michaelthelin.spotify.requests.authorization.client_credentials.ClientCredentialsRequest;
import se.michaelthelin.spotify.requests.data.search.simplified.SearchTracksRequest;
import se.michaelthelin.spotify.requests.data.tracks.GetTrackRequest;

import java.io.IOException;
import java.net.URI;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Client for interacting with Spotify API
 */
public class SpotifyClient {
    private static final Logger logger = LoggerFactory.getLogger(SpotifyClient.class);
    private static final Pattern SPOTIFY_URI_PATTERN = Pattern.compile("spotify:track:([a-zA-Z0-9]+)");
    private static final Pattern SPOTIFY_URL_PATTERN = Pattern.compile("https://open\\.spotify\\.com/track/([a-zA-Z0-9]+)");
    
    private final SpotifyApi spotifyApi;
    private Instant tokenExpirationTime;
    private final ScheduledExecutorService scheduler;
    
    /**
     * Create a new Spotify client
     */
    public SpotifyClient() {
        ConfigLoader config = ConfigLoader.getInstance();
        String clientId = config.getSpotifyClientId();
        String clientSecret = config.getSpotifyClientSecret();
        
        // Initialize Spotify API
        spotifyApi = new SpotifyApi.Builder()
                .setClientId(clientId)
                .setClientSecret(clientSecret)
                .build();
        
        scheduler = Executors.newScheduledThreadPool(1);
        
        // Authenticate immediately and refresh token periodically
        refreshAccessToken();
    }
    
    /**
     * Refresh Spotify access token
     */
    private void refreshAccessToken() {
        try {
            ClientCredentialsRequest credentialsRequest = spotifyApi.clientCredentials().build();
            ClientCredentials credentials = credentialsRequest.execute();
            
            // Set access token
            spotifyApi.setAccessToken(credentials.getAccessToken());
            
            // Calculate expiration time (subtract 5 minutes for safety)
            long expiresIn = credentials.getExpiresIn() - 300;
            tokenExpirationTime = Instant.now().plusSeconds(expiresIn);
            
            logger.info("Spotify token refreshed, expires in {} seconds", expiresIn);
            
            // Schedule next refresh before token expires
            scheduler.schedule(this::refreshAccessToken, expiresIn, TimeUnit.SECONDS);
        } catch (IOException | SpotifyWebApiException e) {
            logger.error("Error refreshing Spotify token", e);
            
            // Retry after 60 seconds
            scheduler.schedule(this::refreshAccessToken, 60, TimeUnit.SECONDS);
        } catch (Exception e) {
            logger.error("Unexpected error refreshing Spotify token", e);
            
            // Retry after 60 seconds
            scheduler.schedule(this::refreshAccessToken, 60, TimeUnit.SECONDS);
        }
    }
    
    /**
     * Search for tracks on Spotify
     * @param query Search query
     * @param limit Maximum number of results
     * @return List of tracks
     */
    public List<Track> searchTracks(String query, int limit) {
        ensureTokenValid();
        List<Track> results = new ArrayList<>();
        
        try {
            // Create search request
            SearchTracksRequest searchRequest = spotifyApi.searchTracks(query)
                    .limit(limit)
                    .build();
            
            // Execute search
            Paging<Track> trackPaging = searchRequest.execute();
            Track[] tracks = trackPaging.getItems();
            
            // Add tracks to results
            if (tracks != null) {
                for (Track track : tracks) {
                    results.add(track);
                }
            }
            
            logger.info("Found {} tracks for query: {}", results.size(), query);
        } catch (IOException | SpotifyWebApiException e) {
            logger.error("Error searching for tracks: {}", query, e);
        } catch (Exception e) {
            logger.error("Unexpected error searching for tracks: {}", query, e);
        }
        
        return results;
    }
    
    /**
     * Get a track by Spotify URL or ID
     * @param spotifyUrl Spotify URL or ID
     * @return Track or null if not found
     */
    public Track getTrack(String spotifyUrl) {
        String trackId = extractTrackId(spotifyUrl);
        if (trackId == null) {
            logger.error("Invalid Spotify URL or ID: {}", spotifyUrl);
            return null;
        }
        
        ensureTokenValid();
        
        try {
            // Create get track request
            GetTrackRequest getTrackRequest = spotifyApi.getTrack(trackId).build();
            
            // Execute request
            Track track = getTrackRequest.execute();
            
            logger.info("Found track: {} by {}", track.getName(), track.getArtists()[0].getName());
            return track;
        } catch (IOException | SpotifyWebApiException e) {
            logger.error("Error getting track: {}", trackId, e);
        } catch (Exception e) {
            logger.error("Unexpected error getting track: {}", trackId, e);
        }
        
        return null;
    }
    
    /**
     * Extract track ID from Spotify URL or URI
     * @param input Spotify URL, URI, or ID
     * @return Track ID or null if invalid
     */
    private String extractTrackId(String input) {
        if (input == null || input.trim().isEmpty()) {
            return null;
        }
        
        // Check if it's already just an ID
        if (input.matches("^[a-zA-Z0-9]{22}$")) {
            return input;
        }
        
        // Check if it's a Spotify URI
        Matcher uriMatcher = SPOTIFY_URI_PATTERN.matcher(input);
        if (uriMatcher.find()) {
            return uriMatcher.group(1);
        }
        
        // Check if it's a Spotify URL
        Matcher urlMatcher = SPOTIFY_URL_PATTERN.matcher(input);
        if (urlMatcher.find()) {
            return urlMatcher.group(1);
        }
        
        return null;
    }
    
    /**
     * Ensure the access token is valid
     */
    private void ensureTokenValid() {
        if (tokenExpirationTime == null || Instant.now().isAfter(tokenExpirationTime)) {
            refreshAccessToken();
        }
    }
    
    /**
     * Shutdown the client
     */
    public void shutdown() {
        scheduler.shutdown();
        try {
            if (!scheduler.awaitTermination(10, TimeUnit.SECONDS)) {
                scheduler.shutdownNow();
            }
        } catch (InterruptedException e) {
            scheduler.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
}