package com.swooshbot.discordbot;

import com.swooshbot.discordbot.api.ApiServer;
import com.swooshbot.discordbot.audio.PlayerManager;
import com.swooshbot.discordbot.commands.CommandManager;
import com.swooshbot.discordbot.config.ConfigLoader;
import com.swooshbot.discordbot.spotify.SpotifyClient;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.utils.ChunkingFilter;
import net.dv8tion.jda.api.utils.MemberCachePolicy;
import net.dv8tion.jda.api.utils.cache.CacheFlag;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.concurrent.CountDownLatch;

/**
 * Main class for the Discord Music Bot
 */
public class MusicBot extends ListenerAdapter {
    private static final Logger logger = LoggerFactory.getLogger(MusicBot.class);
    
    private final JDA jda;
    private final SpotifyClient spotifyClient;
    private final PlayerManager playerManager;
    private final CommandManager commandManager;
    private final Date startTime;
    private ApiServer apiServer;
    
    /**
     * Create a new music bot
     * @throws Exception If an error occurs
     */
    public MusicBot() throws Exception {
        startTime = new Date();
        logger.info("Starting SWOOSH Music Bot...");
        
        // Load configuration
        ConfigLoader config = ConfigLoader.getInstance();
        String token = config.getDiscordToken();
        String prefix = config.getCommandPrefix();
        
        if (token == null || token.isEmpty()) {
            throw new IllegalStateException("Discord token not found in configuration");
        }
        
        // Initialize components
        spotifyClient = new SpotifyClient();
        playerManager = new PlayerManager();
        
        // Build JDA
        jda = JDABuilder.createDefault(token)
                .setStatus(OnlineStatus.ONLINE)
                .setActivity(Activity.listening("Spotify | " + prefix + " help"))
                .enableIntents(
                        GatewayIntent.GUILD_MESSAGES,
                        GatewayIntent.GUILD_VOICE_STATES,
                        GatewayIntent.MESSAGE_CONTENT,
                        GatewayIntent.GUILD_MEMBERS
                )
                .setMemberCachePolicy(MemberCachePolicy.VOICE)
                .setChunkingFilter(ChunkingFilter.NONE)
                .enableCache(CacheFlag.VOICE_STATE)
                .disableCache(
                        CacheFlag.EMOJI,
                        CacheFlag.STICKER,
                        CacheFlag.SCHEDULED_EVENTS
                )
                .build();
        
        // Register listeners
        commandManager = new CommandManager(prefix, playerManager, spotifyClient);
        jda.addEventListener(new MessageListener(commandManager));
        
        // Wait for JDA to be ready
        jda.awaitReady();
        logger.info("Bot is ready! Logged in as {}", jda.getSelfUser().getName());
        
        // Start API server if enabled
        if (config.isApiEnabled()) {
            int port = config.getApiPort();
            apiServer = new ApiServer(port, this);
            apiServer.start();
            logger.info("API server started on port {}", port);
        }
        
        // Add shutdown hook
        Runtime.getRuntime().addShutdownHook(new Thread(this::shutdown));
    }
    
    /**
     * Get the JDA instance
     * @return JDA instance
     */
    public JDA getJda() {
        return jda;
    }
    
    /**
     * Get the player manager
     * @return Player manager
     */
    public PlayerManager getPlayerManager() {
        return playerManager;
    }
    
    /**
     * Get the command manager
     * @return Command manager
     */
    public CommandManager getCommandManager() {
        return commandManager;
    }
    
    /**
     * Get the Spotify client
     * @return Spotify client
     */
    public SpotifyClient getSpotifyClient() {
        return spotifyClient;
    }
    
    /**
     * Get the start time
     * @return Start time
     */
    public Date getStartTime() {
        return startTime;
    }
    
    /**
     * Shutdown the bot
     */
    public void shutdown() {
        logger.info("Shutting down bot...");
        
        // Shutdown API server if running
        if (apiServer != null) {
            apiServer.stop();
        }
        
        // Shutdown Spotify client
        if (spotifyClient != null) {
            spotifyClient.shutdown();
        }
        
        // Shutdown JDA
        if (jda != null) {
            jda.shutdown();
        }
        
        logger.info("Bot shut down successfully");
    }
    
    /**
     * Main method
     * @param args Command line arguments
     */
    public static void main(String[] args) {
        try {
            // Start bot
            MusicBot bot = new MusicBot();
            
            // Keep the program running
            CountDownLatch latch = new CountDownLatch(1);
            latch.await();
        } catch (Exception e) {
            logger.error("Error starting bot", e);
            System.exit(1);
        }
    }
}