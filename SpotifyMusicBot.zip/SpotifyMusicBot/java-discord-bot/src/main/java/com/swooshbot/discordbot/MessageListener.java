package com.swooshbot.discordbot;

import com.swooshbot.discordbot.commands.CommandManager;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;
import org.jetbrains.annotations.NotNull;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Listener for Discord messages
 */
public class MessageListener extends ListenerAdapter {
    private static final Logger logger = LoggerFactory.getLogger(MessageListener.class);
    private final CommandManager commandManager;
    
    /**
     * Create a new message listener
     * @param commandManager Command manager
     */
    public MessageListener(CommandManager commandManager) {
        this.commandManager = commandManager;
    }
    
    @Override
    public void onMessageReceived(@NotNull MessageReceivedEvent event) {
        // Ignore messages from bots
        if (event.getAuthor().isBot()) {
            return;
        }
        
        String content = event.getMessage().getContentRaw();
        
        // Handle commands
        if (commandManager.isCommand(content)) {
            logger.debug("Received command: {}", content);
            commandManager.handleCommand(event);
        }
    }
}