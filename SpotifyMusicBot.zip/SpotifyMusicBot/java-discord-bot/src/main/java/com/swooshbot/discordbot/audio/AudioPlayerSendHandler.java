package com.swooshbot.discordbot.audio;

import com.sedmelluq.discord.lavaplayer.player.AudioPlayer;
import com.sedmelluq.discord.lavaplayer.track.playback.MutableAudioFrame;
import net.dv8tion.jda.api.audio.AudioSendHandler;

import java.nio.Buffer;
import java.nio.ByteBuffer;

/**
 * Send handler for audio playback
 */
public class AudioPlayerSendHandler implements AudioSendHandler {
    private final AudioPlayer audioPlayer;
    private final ByteBuffer buffer;
    private final MutableAudioFrame frame;
    
    /**
     * Create a new audio player send handler
     * @param audioPlayer Audio player
     */
    public AudioPlayerSendHandler(AudioPlayer audioPlayer) {
        this.audioPlayer = audioPlayer;
        this.buffer = ByteBuffer.allocate(1024);
        this.frame = new MutableAudioFrame();
        this.frame.setBuffer(buffer);
    }
    
    @Override
    public boolean canProvide() {
        // Returns true if audio was provided
        return audioPlayer.provide(frame);
    }
    
    @Override
    public ByteBuffer provide20MsAudio() {
        // Flip to make it a read buffer
        ((Buffer) buffer).flip();
        return buffer;
    }
    
    @Override
    public boolean isOpus() {
        return true;
    }
}