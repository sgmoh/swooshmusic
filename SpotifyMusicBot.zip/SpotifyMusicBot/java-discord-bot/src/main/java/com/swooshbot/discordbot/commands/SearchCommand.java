package com.swooshbot.discordbot.commands;

import com.swooshbot.discordbot.spotify.SpotifyClient;
import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import se.michaelthelin.spotify.model_objects.specification.ArtistSimplified;
import se.michaelthelin.spotify.model_objects.specification.Track;

import java.awt.Color;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Command to search for tracks on Spotify
 */
public class SearchCommand implements Command {
    private static final Logger logger = LoggerFactory.getLogger(SearchCommand.class);
    private static final int MAX_RESULTS = 5;
    
    private final SpotifyClient spotifyClient;
    
    /**
     * Create a new search command
     * @param spotifyClient Spotify client
     */
    public SearchCommand(SpotifyClient spotifyClient) {
        this.spotifyClient = spotifyClient;
    }
    
    @Override
    public String getName() {
        return "search";
    }
    
    @Override
    public String getDescription() {
        return "Search for tracks on Spotify";
    }
    
    @Override
    public String getUsage() {
        return "search <query>";
    }
    
    @Override
    public void execute(MessageReceivedEvent event, String args) {
        if (args == null || args.trim().isEmpty()) {
            event.getChannel().sendMessage("❌ Please provide a search query. Use `search <query>`").queue();
            return;
        }
        
        event.getChannel().sendMessage("🔍 Searching Spotify for: **" + args + "**").queue(loadingMessage -> {
            try {
                // Search on Spotify
                List<Track> results = spotifyClient.searchTracks(args, MAX_RESULTS);
                
                if (results.isEmpty()) {
                    loadingMessage.editMessage("❌ No results found for: **" + args + "**").queue();
                    return;
                }
                
                // Build results embed
                EmbedBuilder embed = new EmbedBuilder();
                embed.setColor(new Color(30, 215, 96)); // Spotify green
                embed.setTitle("🔍 Spotify Search Results");
                embed.setDescription("Query: **" + args + "**");
                
                // Add each track to the embed
                for (int i = 0; i < results.size(); i++) {
                    Track track = results.get(i);
                    
                    // Format artist names
                    String artists = formatArtists(track.getArtists());
                    
                    // Format duration
                    String duration = formatDuration(track.getDurationMs());
                    
                    // Add track to embed
                    embed.addField(
                            (i + 1) + ". " + track.getName(),
                            "Artist: " + artists + "\n" +
                            "Album: " + track.getAlbum().getName() + "\n" +
                            "Duration: " + duration + "\n" +
                            "ID: `" + track.getId() + "`",
                            false
                    );
                }
                
                // Add footer
                embed.setFooter("Use .music play <song name> to play a track");
                
                // Send embed
                loadingMessage.editMessageEmbeds(embed.build()).queue();
                
            } catch (Exception e) {
                logger.error("Error searching for tracks", e);
                loadingMessage.editMessage("❌ Error: " + e.getMessage()).queue();
            }
        });
    }
    
    /**
     * Format artist names
     * @param artists Artists array
     * @return Formatted artist names
     */
    private String formatArtists(ArtistSimplified[] artists) {
        if (artists == null || artists.length == 0) {
            return "Unknown";
        }
        
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < artists.length; i++) {
            if (i > 0) {
                sb.append(", ");
            }
            sb.append(artists[i].getName());
        }
        
        return sb.toString();
    }
    
    /**
     * Format duration in mm:ss format
     * @param durationMs Duration in milliseconds
     * @return Formatted duration string
     */
    private String formatDuration(long durationMs) {
        long minutes = TimeUnit.MILLISECONDS.toMinutes(durationMs);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(durationMs) - TimeUnit.MINUTES.toSeconds(minutes);
        return String.format("%d:%02d", minutes, seconds);
    }
}