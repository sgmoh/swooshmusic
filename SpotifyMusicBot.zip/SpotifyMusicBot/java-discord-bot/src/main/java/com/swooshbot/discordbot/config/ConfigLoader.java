package com.swooshbot.discordbot.config;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Properties;

/**
 * Configuration loader for the bot
 */
public class ConfigLoader {
    private static final Logger logger = LoggerFactory.getLogger(ConfigLoader.class);
    
    private Properties properties;
    private static ConfigLoader instance;
    
    /**
     * Create a new configuration loader
     */
    private ConfigLoader() {
        properties = new Properties();
        loadConfig();
    }
    
    /**
     * Get the singleton instance
     * @return The config loader instance
     */
    public static ConfigLoader getInstance() {
        if (instance == null) {
            instance = new ConfigLoader();
        }
        return instance;
    }
    
    /**
     * Load configuration from various sources
     */
    private void loadConfig() {
        // First try to load from config.properties
        boolean loadedProperties = loadFromProperties();
        
        // Then try to load from .env file
        boolean loadedEnv = loadFromEnvFile();
        
        // Finally, override with system environment variables
        loadFromEnvironment();
        
        // Log the loading results
        if (!loadedProperties && !loadedEnv) {
            logger.warn("No config files found. Using only environment variables.");
        }
        
        // Validate essential configuration
        validateConfig();
    }
    
    /**
     * Load configuration from config.properties
     * @return True if loaded successfully
     */
    private boolean loadFromProperties() {
        try {
            // First try loading from resources
            try (InputStream input = getClass().getClassLoader().getResourceAsStream("config.properties")) {
                if (input != null) {
                    properties.load(input);
                    logger.info("Loaded configuration from resources/config.properties");
                    return true;
                }
            }
            
            // Then try loading from file
            Path configPath = Paths.get("config.properties");
            if (Files.exists(configPath)) {
                try (FileInputStream input = new FileInputStream(configPath.toFile())) {
                    properties.load(input);
                    logger.info("Loaded configuration from config.properties file");
                    return true;
                }
            }
        } catch (IOException e) {
            logger.error("Error loading config.properties", e);
        }
        
        return false;
    }
    
    /**
     * Load configuration from .env file
     * @return True if loaded successfully
     */
    private boolean loadFromEnvFile() {
        Path envPath = Paths.get(".env");
        if (!Files.exists(envPath)) {
            return false;
        }
        
        try {
            // Parse .env file format (KEY=VALUE)
            Files.lines(envPath)
                .map(String::trim)
                .filter(line -> !line.isEmpty() && !line.startsWith("#"))
                .forEach(line -> {
                    String[] parts = line.split("=", 2);
                    if (parts.length == 2) {
                        String key = parts[0].trim();
                        String value = parts[1].trim();
                        
                        // Convert environment variable names to property names
                        String propertyKey = convertEnvToPropertyKey(key);
                        properties.setProperty(propertyKey, value);
                    }
                });
            
            logger.info("Loaded configuration from .env file");
            return true;
        } catch (IOException e) {
            logger.error("Error loading .env file", e);
            return false;
        }
    }
    
    /**
     * Load configuration from environment variables
     */
    private void loadFromEnvironment() {
        // Map environment variables to property keys
        mapEnvToProperty("DISCORD_TOKEN", "discord.token");
        mapEnvToProperty("SPOTIFY_CLIENT_ID", "spotify.clientId");
        mapEnvToProperty("SPOTIFY_CLIENT_SECRET", "spotify.clientSecret");
        mapEnvToProperty("API_PORT", "api.port");
    }
    
    /**
     * Map an environment variable to a property if it exists
     * @param envKey Environment variable name
     * @param propKey Property key
     */
    private void mapEnvToProperty(String envKey, String propKey) {
        String value = System.getenv(envKey);
        if (value != null && !value.isEmpty()) {
            properties.setProperty(propKey, value);
            logger.debug("Loaded {} from environment variable", propKey);
        }
    }
    
    /**
     * Convert environment variable names to property keys
     * @param envKey Environment variable name
     * @return Property key
     */
    private String convertEnvToPropertyKey(String envKey) {
        switch (envKey) {
            case "DISCORD_TOKEN": return "discord.token";
            case "SPOTIFY_CLIENT_ID": return "spotify.clientId";
            case "SPOTIFY_CLIENT_SECRET": return "spotify.clientSecret";
            case "API_PORT": return "api.port";
            default: return envKey.toLowerCase();
        }
    }
    
    /**
     * Validate essential configuration
     */
    private void validateConfig() {
        boolean valid = true;
        
        // Check required properties
        if (!hasProperty("discord.token")) {
            logger.error("Missing discord.token configuration");
            valid = false;
        }
        
        if (!hasProperty("spotify.clientId")) {
            logger.error("Missing spotify.clientId configuration");
            valid = false;
        }
        
        if (!hasProperty("spotify.clientSecret")) {
            logger.error("Missing spotify.clientSecret configuration");
            valid = false;
        }
        
        if (!valid) {
            logger.error("Essential configuration missing. Please check your config.properties or environment variables.");
        }
    }
    
    /**
     * Check if a property exists and is not empty
     * @param key Property key
     * @return True if the property exists and is not empty
     */
    private boolean hasProperty(String key) {
        String value = properties.getProperty(key);
        return value != null && !value.isEmpty() && !value.startsWith("YOUR_");
    }
    
    /**
     * Get a property value
     * @param key Property key
     * @return Property value or null if not found
     */
    public String getProperty(String key) {
        return properties.getProperty(key);
    }
    
    /**
     * Get a property value with a default
     * @param key Property key
     * @param defaultValue Default value
     * @return Property value or default if not found
     */
    public String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }
    
    /**
     * Get a property as an integer
     * @param key Property key
     * @param defaultValue Default value
     * @return Property value as integer or default if not found
     */
    public int getIntProperty(String key, int defaultValue) {
        String value = properties.getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        
        try {
            return Integer.parseInt(value);
        } catch (NumberFormatException e) {
            logger.warn("Invalid integer value for property {}: {}", key, value);
            return defaultValue;
        }
    }
    
    /**
     * Get a property as a boolean
     * @param key Property key
     * @param defaultValue Default value
     * @return Property value as boolean or default if not found
     */
    public boolean getBooleanProperty(String key, boolean defaultValue) {
        String value = properties.getProperty(key);
        if (value == null) {
            return defaultValue;
        }
        
        return Boolean.parseBoolean(value);
    }
    
    /**
     * Get Discord bot token
     * @return Discord bot token
     */
    public String getDiscordToken() {
        return getProperty("discord.token");
    }
    
    /**
     * Get command prefix
     * @return Command prefix
     */
    public String getCommandPrefix() {
        return getProperty("discord.prefix", ".music");
    }
    
    /**
     * Get Spotify client ID
     * @return Spotify client ID
     */
    public String getSpotifyClientId() {
        return getProperty("spotify.clientId");
    }
    
    /**
     * Get Spotify client secret
     * @return Spotify client secret
     */
    public String getSpotifyClientSecret() {
        return getProperty("spotify.clientSecret");
    }
    
    /**
     * Get API port
     * @return API port
     */
    public int getApiPort() {
        return getIntProperty("api.port", 8787);
    }
    
    /**
     * Check if API is enabled
     * @return True if API is enabled
     */
    public boolean isApiEnabled() {
        return getBooleanProperty("api.enabled", true);
    }
}