package com.swooshbot.discordbot.audio;

import com.sedmelluq.discord.lavaplayer.player.AudioLoadResultHandler;
import com.sedmelluq.discord.lavaplayer.player.AudioPlayerManager;
import com.sedmelluq.discord.lavaplayer.player.DefaultAudioPlayerManager;
import com.sedmelluq.discord.lavaplayer.source.AudioSourceManagers;
import com.sedmelluq.discord.lavaplayer.tools.FriendlyException;
import com.sedmelluq.discord.lavaplayer.track.AudioPlaylist;
import com.sedmelluq.discord.lavaplayer.track.AudioTrack;
import net.dv8tion.jda.api.entities.Guild;
import net.dv8tion.jda.api.entities.channel.concrete.VoiceChannel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manager for audio players
 */
public class PlayerManager {
    private static final Logger logger = LoggerFactory.getLogger(PlayerManager.class);
    
    private final AudioPlayerManager playerManager;
    private final Map<String, GuildMusicManager> musicManagers;
    
    /**
     * Create a new player manager
     */
    public PlayerManager() {
        this.playerManager = new DefaultAudioPlayerManager();
        this.musicManagers = new ConcurrentHashMap<>();
        
        // Register audio sources
        AudioSourceManagers.registerRemoteSources(playerManager);
        AudioSourceManagers.registerLocalSource(playerManager);
        
        logger.info("PlayerManager initialized");
    }
    
    /**
     * Get a guild music manager
     * @param guildId Guild ID
     * @return Guild music manager
     */
    public GuildMusicManager getGuildMusicManager(String guildId) {
        return musicManagers.computeIfAbsent(guildId, id -> {
            GuildMusicManager manager = new GuildMusicManager(playerManager);
            logger.debug("Created new GuildMusicManager for guild {}", id);
            return manager;
        });
    }
    
    /**
     * Check if a guild music manager exists
     * @param guildId Guild ID
     * @return True if the guild has a music manager
     */
    public boolean hasGuildMusicManager(String guildId) {
        return musicManagers.containsKey(guildId);
    }
    
    /**
     * Load and play a track
     * @param guild Guild to play in
     * @param voiceChannel Voice channel to play in
     * @param trackUrl Track URL or search query
     * @param requester User who requested the track
     * @return CompletableFuture with the result
     */
    public CompletableFuture<LoadResult> loadAndPlay(Guild guild, VoiceChannel voiceChannel, String trackUrl, String requester) {
        GuildMusicManager musicManager = getGuildMusicManager(guild.getId());
        CompletableFuture<LoadResult> future = new CompletableFuture<>();
        
        // Join voice channel if not already connected
        if (!guild.getAudioManager().isConnected()) {
            try {
                guild.getAudioManager().openAudioConnection(voiceChannel);
                logger.info("Connected to voice channel {} in {}", voiceChannel.getName(), guild.getName());
            } catch (Exception e) {
                logger.error("Failed to connect to voice channel", e);
                future.complete(new LoadResult(false, "Failed to connect to voice channel: " + e.getMessage()));
                return future;
            }
        }
        
        // Store voice channel name for API
        musicManager.getTrackScheduler().setVoiceChannelName(voiceChannel.getName());
        
        // Load and play the track
        playerManager.loadItemOrdered(musicManager, trackUrl, new AudioLoadResultHandler() {
            @Override
            public void trackLoaded(AudioTrack track) {
                logger.info("Adding to queue: {} by {}", track.getInfo().title, track.getInfo().author);
                
                // Set requester as user data
                track.setUserData(requester);
                
                // Queue the track
                musicManager.getTrackScheduler().queue(track);
                
                future.complete(new LoadResult(true, "Track added to queue", track));
            }
            
            @Override
            public void playlistLoaded(AudioPlaylist playlist) {
                if (playlist.isSearchResult()) {
                    // Take first result from search
                    AudioTrack track = playlist.getTracks().get(0);
                    logger.info("Adding to queue (search result): {} by {}", track.getInfo().title, track.getInfo().author);
                    
                    // Set requester as user data
                    track.setUserData(requester);
                    
                    // Queue the track
                    musicManager.getTrackScheduler().queue(track);
                    
                    future.complete(new LoadResult(true, "Track added to queue", track));
                } else {
                    // Queue all tracks from playlist
                    for (AudioTrack track : playlist.getTracks()) {
                        track.setUserData(requester);
                        musicManager.getTrackScheduler().queue(track);
                    }
                    
                    logger.info("Added {} tracks from playlist: {}", playlist.getTracks().size(), playlist.getName());
                    future.complete(new LoadResult(true, 
                        "Added " + playlist.getTracks().size() + " tracks from playlist", 
                        playlist.getTracks().get(0)));
                }
            }
            
            @Override
            public void noMatches() {
                logger.warn("No matches found for: {}", trackUrl);
                future.complete(new LoadResult(false, "No matches found for query"));
            }
            
            @Override
            public void loadFailed(FriendlyException e) {
                logger.error("Failed to load track", e);
                future.complete(new LoadResult(false, "Failed to load track: " + e.getMessage()));
            }
        });
        
        return future;
    }
    
    /**
     * Result of loading a track
     */
    public static class LoadResult {
        private final boolean success;
        private final String message;
        private final AudioTrack track;
        
        public LoadResult(boolean success, String message) {
            this(success, message, null);
        }
        
        public LoadResult(boolean success, String message, AudioTrack track) {
            this.success = success;
            this.message = message;
            this.track = track;
        }
        
        public boolean isSuccess() {
            return success;
        }
        
        public String getMessage() {
            return message;
        }
        
        public AudioTrack getTrack() {
            return track;
        }
    }
}