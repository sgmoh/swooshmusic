package com.swooshbot.discordbot.api;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.swooshbot.discordbot.MusicBot;
import com.swooshbot.discordbot.audio.GuildMusicManager;
import com.swooshbot.discordbot.commands.CommandManager;
import io.javalin.Javalin;
import io.javalin.plugin.bundled.CorsPluginConfig;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.Guild;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

/**
 * API server for exposing data to the web dashboard
 */
public class ApiServer {
    private static final Logger logger = LoggerFactory.getLogger(ApiServer.class);
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("HH:mm:ss MM/dd/yyyy");
    
    private final int port;
    private final MusicBot bot;
    private final Gson gson;
    private Javalin app;
    
    /**
     * Create a new API server
     * @param port Port to listen on
     * @param bot Music bot instance
     */
    public ApiServer(int port, MusicBot bot) {
        this.port = port;
        this.bot = bot;
        this.gson = new GsonBuilder().setPrettyPrinting().create();
    }
    
    /**
     * Start the API server
     */
    public void start() {
        try {
            app = Javalin.create(config -> {
                config.plugins.enableCors(cors -> {
                    cors.add(CorsPluginConfig::anyHost);
                });
            }).start(port);
            
            // Register routes
            setupRoutes();
            
            logger.info("API server started on port {}", port);
        } catch (Exception e) {
            logger.error("Failed to start API server", e);
        }
    }
    
    /**
     * Set up API routes
     */
    private void setupRoutes() {
        // Health check endpoint
        app.get("/health", ctx -> {
            ctx.result("OK");
        });
        
        // Bot status
        app.get("/api/status", ctx -> {
            JDA jda = bot.getJda();
            Map<String, Object> status = new HashMap<>();
            
            status.put("isOnline", jda.getStatus() == JDA.Status.CONNECTED);
            status.put("uptime", formatUptime(bot.getStartTime()));
            status.put("serverCount", jda.getGuilds().size());
            status.put("id", jda.getSelfUser().getId());
            status.put("startupTime", DATE_FORMAT.format(bot.getStartTime()));
            status.put("lastUpdated", DATE_FORMAT.format(new Date()));
            
            ctx.contentType("application/json");
            ctx.result(gson.toJson(status));
        });
        
        // Command usage
        app.get("/api/commands", ctx -> {
            CommandManager commandManager = bot.getCommandManager();
            int limit = ctx.queryParamAsClass("limit", Integer.class).getOrDefault(100);
            
            List<Map<String, Object>> commands = new ArrayList<>();
            commandManager.getCommandUsageHistory(limit).forEach(usage -> {
                Map<String, Object> command = new HashMap<>();
                command.put("timestamp", usage.getTimestamp());
                command.put("formattedTime", DATE_FORMAT.format(new Date(usage.getTimestamp())));
                command.put("command", usage.getCommand());
                command.put("user", usage.getUser());
                command.put("serverId", usage.getServerId());
                command.put("serverName", usage.getServerName());
                command.put("success", usage.isSuccess());
                command.put("errorMessage", usage.getErrorMessage());
                commands.add(command);
            });
            
            ctx.contentType("application/json");
            ctx.result(gson.toJson(commands));
        });
        
        // Currently playing
        app.get("/api/playing", ctx -> {
            Map<String, Object> playingData = getCurrentlyPlaying();
            
            if (playingData == null) {
                ctx.status(404);
                ctx.contentType("application/json");
                ctx.result(gson.toJson(Map.of("message", "No track currently playing")));
                return;
            }
            
            ctx.contentType("application/json");
            ctx.result(gson.toJson(playingData));
        });
        
        // Server list
        app.get("/api/servers", ctx -> {
            JDA jda = bot.getJda();
            List<Map<String, Object>> servers = new ArrayList<>();
            
            for (Guild guild : jda.getGuilds()) {
                Map<String, Object> server = new HashMap<>();
                server.put("id", guild.getId());
                server.put("name", guild.getName());
                server.put("memberCount", guild.getMemberCount());
                server.put("isPlaying", bot.getPlayerManager().hasGuildMusicManager(guild.getId()));
                servers.add(server);
            }
            
            ctx.contentType("application/json");
            ctx.result(gson.toJson(servers));
        });
    }
    
    /**
     * Get information about the currently playing track
     * @return Track information or null if nothing is playing
     */
    private Map<String, Object> getCurrentlyPlaying() {
        // Find a guild that's playing music
        for (Guild guild : bot.getJda().getGuilds()) {
            GuildMusicManager musicManager = bot.getPlayerManager().getGuildMusicManager(guild.getId());
            
            if (musicManager != null && musicManager.getTrackScheduler().getCurrentTrack() != null) {
                Map<String, Object> trackInfo = new HashMap<>();
                com.sedmelluq.discord.lavaplayer.track.AudioTrack track = musicManager.getTrackScheduler().getCurrentTrack();
                Date startedAt = musicManager.getTrackScheduler().getTrackStartTime();
                
                // Calculate progress
                long durationMs = track.getDuration();
                long progressMs = System.currentTimeMillis() - startedAt.getTime();
                long remaining = durationMs - progressMs;
                double progressPercent = Math.min(100.0, Math.max(0.0, (progressMs * 100.0) / durationMs));
                boolean isPlaying = musicManager.getAudioPlayer().getPlayingTrack() != null && !musicManager.getAudioPlayer().isPaused();
                
                // Format progress and duration strings
                String formattedProgress = formatDuration(progressMs);
                String formattedDuration = formatDuration(durationMs);
                
                // Build track info
                trackInfo.put("id", track.getIdentifier());
                trackInfo.put("trackName", track.getInfo().title);
                trackInfo.put("artistName", track.getInfo().author);
                trackInfo.put("albumName", "Unknown"); // LavaPlayer doesn't provide this
                trackInfo.put("duration", durationMs);
                trackInfo.put("progress", progressMs);
                trackInfo.put("progressPercent", progressPercent);
                trackInfo.put("server", guild.getName());
                trackInfo.put("channel", musicManager.getTrackScheduler().getVoiceChannelName());
                trackInfo.put("startedAt", DATE_FORMAT.format(startedAt));
                trackInfo.put("isPlaying", isPlaying);
                trackInfo.put("formattedProgress", formattedProgress);
                trackInfo.put("formattedDuration", formattedDuration);
                
                return trackInfo;
            }
        }
        
        return null;
    }
    
    /**
     * Format uptime from a start date to a human-readable string
     * @param startTime The start time
     * @return Formatted uptime string like "5d 12h 34m"
     */
    private String formatUptime(Date startTime) {
        long uptime = System.currentTimeMillis() - startTime.getTime();
        
        long days = TimeUnit.MILLISECONDS.toDays(uptime);
        uptime -= TimeUnit.DAYS.toMillis(days);
        
        long hours = TimeUnit.MILLISECONDS.toHours(uptime);
        uptime -= TimeUnit.HOURS.toMillis(hours);
        
        long minutes = TimeUnit.MILLISECONDS.toMinutes(uptime);
        
        return String.format("%dd %dh %dm", days, hours, minutes);
    }
    
    /**
     * Format a duration in milliseconds to a human-readable string
     * @param durationMs Duration in milliseconds
     * @return Formatted duration string like "3:45"
     */
    private String formatDuration(long durationMs) {
        long minutes = TimeUnit.MILLISECONDS.toMinutes(durationMs);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(durationMs) - TimeUnit.MINUTES.toSeconds(minutes);
        
        return String.format("%d:%02d", minutes, seconds);
    }
    
    /**
     * Stop the API server
     */
    public void stop() {
        if (app != null) {
            app.stop();
            logger.info("API server stopped");
        }
    }
}