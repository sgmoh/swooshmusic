package com.swooshbot.discordbot.audio;

import com.sedmelluq.discord.lavaplayer.player.AudioPlayer;
import com.sedmelluq.discord.lavaplayer.player.event.AudioEventAdapter;
import com.sedmelluq.discord.lavaplayer.track.AudioTrack;
import com.sedmelluq.discord.lavaplayer.track.AudioTrackEndReason;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * Track scheduler for audio playback
 */
public class TrackScheduler extends AudioEventAdapter {
    private static final Logger logger = LoggerFactory.getLogger(TrackScheduler.class);
    
    private final AudioPlayer player;
    private final BlockingQueue<AudioTrack> queue;
    private AudioTrack currentTrack;
    private Date trackStartTime;
    private String voiceChannelName;
    
    /**
     * Create a new track scheduler
     * @param player Audio player
     */
    public TrackScheduler(AudioPlayer player) {
        this.player = player;
        this.queue = new LinkedBlockingQueue<>();
    }
    
    /**
     * Queue a track
     * @param track Track to queue
     */
    public void queue(AudioTrack track) {
        // If nothing is playing, play immediately
        if (player.getPlayingTrack() == null) {
            play(track);
        } else {
            // Otherwise add to queue
            queue.offer(track);
        }
    }
    
    /**
     * Start playing a track
     * @param track Track to play
     */
    public void play(AudioTrack track) {
        player.setPaused(false);
        player.startTrack(track, false);
        currentTrack = track;
        trackStartTime = new Date();
        logger.info("Now playing: {} by {}", track.getInfo().title, track.getInfo().author);
    }
    
    /**
     * Skip to the next track
     * @return True if a track was skipped
     */
    public boolean skipTrack() {
        // If there's nothing in the queue, stop playback
        if (queue.isEmpty()) {
            player.stopTrack();
            return false;
        }
        
        // Otherwise play the next track
        AudioTrack nextTrack = queue.poll();
        play(nextTrack);
        return true;
    }
    
    /**
     * Clear the queue
     */
    public void clearQueue() {
        queue.clear();
    }
    
    /**
     * Stop playback
     */
    public void stop() {
        player.stopTrack();
        clearQueue();
        currentTrack = null;
    }
    
    /**
     * Set the voice channel name
     * @param voiceChannelName Voice channel name
     */
    public void setVoiceChannelName(String voiceChannelName) {
        this.voiceChannelName = voiceChannelName;
    }
    
    /**
     * Get the voice channel name
     * @return Voice channel name
     */
    public String getVoiceChannelName() {
        return voiceChannelName;
    }
    
    /**
     * Get the current track
     * @return Current track
     */
    public AudioTrack getCurrentTrack() {
        return currentTrack;
    }
    
    /**
     * Get the track start time
     * @return Track start time
     */
    public Date getTrackStartTime() {
        return trackStartTime;
    }
    
    /**
     * Get the queue
     * @return Queue of tracks
     */
    public List<AudioTrack> getQueue() {
        return new LinkedList<>(queue);
    }
    
    @Override
    public void onTrackEnd(AudioPlayer player, AudioTrack track, AudioTrackEndReason endReason) {
        logger.info("Track ended: {} by {}", track.getInfo().title, track.getInfo().author);
        
        // Auto play next track if end of track or error
        if (endReason.mayStartNext) {
            skipTrack();
        }
    }
}