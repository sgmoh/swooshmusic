package com.swooshbot.discordbot.commands;

import com.swooshbot.discordbot.audio.PlayerManager;
import com.swooshbot.discordbot.spotify.SpotifyClient;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Manager for handling commands
 */
public class CommandManager {
    private static final Logger logger = LoggerFactory.getLogger(CommandManager.class);
    
    private final String prefix;
    private final Map<String, Command> commands;
    private final List<CommandUsage> commandUsageHistory;
    
    /**
     * Create a new command manager
     * @param prefix Command prefix (e.g., ".music")
     * @param playerManager Audio player manager
     * @param spotifyClient Spotify client
     */
    public CommandManager(String prefix, PlayerManager playerManager, SpotifyClient spotifyClient) {
        this.prefix = prefix;
        this.commands = new ConcurrentHashMap<>();
        this.commandUsageHistory = new ArrayList<>();
        
        // Register commands
        registerCommand(new PlayCommand(playerManager, spotifyClient));
        registerCommand(new SearchCommand(spotifyClient));
        registerCommand(new QueueCommand(playerManager));
        registerCommand(new ControlsCommand(playerManager));
        registerCommand(new HelpCommand(this));
        
        logger.info("CommandManager initialized with prefix: {}", prefix);
    }
    
    /**
     * Register a command
     * @param command The command to register
     */
    private void registerCommand(Command command) {
        commands.put(command.getName().toLowerCase(), command);
        logger.debug("Registered command: {}", command.getName());
    }
    
    /**
     * Check if a message is a command
     * @param content Message content
     * @return True if the message is a command
     */
    public boolean isCommand(String content) {
        return content.startsWith(prefix);
    }
    
    /**
     * Handle a command
     * @param event Message event
     */
    public void handleCommand(MessageReceivedEvent event) {
        String content = event.getMessage().getContentRaw();
        String[] parts = content.split("\\s+", 2);
        
        if (parts.length == 0) {
            return;
        }
        
        // Extract the command name and arguments
        String commandString = parts[0];
        String commandName = commandString.substring(prefix.length()).toLowerCase();
        String args = parts.length > 1 ? parts[1] : "";
        
        // Log command usage
        String serverId = event.isFromGuild() ? event.getGuild().getId() : "DM";
        String serverName = event.isFromGuild() ? event.getGuild().getName() : "DM";
        CommandUsage usage = new CommandUsage(
                System.currentTimeMillis(),
                content,
                event.getAuthor().getName(),
                serverId,
                serverName,
                true,
                null
        );
        
        // Add to history
        synchronized (commandUsageHistory) {
            commandUsageHistory.add(usage);
            // Keep only the last 100 commands
            if (commandUsageHistory.size() > 100) {
                commandUsageHistory.subList(0, commandUsageHistory.size() - 100).clear();
            }
        }
        
        // Find and execute the command
        Command command = commands.get(commandName);
        if (command != null) {
            logger.info("Executing command '{}' with args '{}' from user {}", 
                    commandName, args, event.getAuthor().getName());
            
            try {
                command.execute(event, args);
            } catch (Exception e) {
                logger.error("Error executing command: {}", commandName, e);
                usage.setSuccess(false);
                usage.setErrorMessage(e.getMessage());
                event.getChannel().sendMessage("❌ Error: " + e.getMessage()).queue();
            }
        } else {
            logger.warn("Unknown command: {}", commandName);
            usage.setSuccess(false);
            usage.setErrorMessage("Unknown command");
            event.getChannel().sendMessage("❌ Unknown command. Use `" + prefix + " help` to see available commands.").queue();
        }
    }
    
    /**
     * Get all registered commands
     * @return List of commands
     */
    public List<Command> getCommands() {
        return new ArrayList<>(commands.values());
    }
    
    /**
     * Get command usage history
     * @param limit Maximum number of entries to return
     * @return List of command usages
     */
    public List<CommandUsage> getCommandUsageHistory(int limit) {
        synchronized (commandUsageHistory) {
            if (limit <= 0 || limit >= commandUsageHistory.size()) {
                return new ArrayList<>(commandUsageHistory);
            }
            
            return new ArrayList<>(commandUsageHistory.subList(
                    commandUsageHistory.size() - limit, 
                    commandUsageHistory.size()));
        }
    }
    
    /**
     * Get the command prefix
     * @return The command prefix
     */
    public String getPrefix() {
        return prefix;
    }
    
    /**
     * Command usage information
     */
    public static class CommandUsage {
        private final long timestamp;
        private final String command;
        private final String user;
        private final String serverId;
        private final String serverName;
        private boolean success;
        private String errorMessage;
        
        public CommandUsage(long timestamp, String command, String user, String serverId, 
                           String serverName, boolean success, String errorMessage) {
            this.timestamp = timestamp;
            this.command = command;
            this.user = user;
            this.serverId = serverId;
            this.serverName = serverName;
            this.success = success;
            this.errorMessage = errorMessage;
        }
        
        public long getTimestamp() {
            return timestamp;
        }
        
        public String getCommand() {
            return command;
        }
        
        public String getUser() {
            return user;
        }
        
        public String getServerId() {
            return serverId;
        }
        
        public String getServerName() {
            return serverName;
        }
        
        public boolean isSuccess() {
            return success;
        }
        
        public void setSuccess(boolean success) {
            this.success = success;
        }
        
        public String getErrorMessage() {
            return errorMessage;
        }
        
        public void setErrorMessage(String errorMessage) {
            this.errorMessage = errorMessage;
        }
    }
}