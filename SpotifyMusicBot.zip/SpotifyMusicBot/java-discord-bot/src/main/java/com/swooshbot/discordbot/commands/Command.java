package com.swooshbot.discordbot.commands;

import net.dv8tion.jda.api.events.message.MessageReceivedEvent;

/**
 * Interface for bot commands
 */
public interface Command {
    /**
     * Get the command name
     * @return Command name
     */
    String getName();
    
    /**
     * Get the command description
     * @return Command description
     */
    String getDescription();
    
    /**
     * Get usage instructions for the command
     * @return Usage instructions
     */
    String getUsage();
    
    /**
     * Execute the command
     * @param event Message event that triggered the command
     * @param args Command arguments
     */
    void execute(MessageReceivedEvent event, String args);
}