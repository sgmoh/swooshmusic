import { useEffect, useState } from 'react';

// Custom snowflake component
const Snowflake = ({ style }: { style: React.CSSProperties }) => {
  return (
    <div 
      className="snowflake text-white opacity-70" 
      style={style}
    >
      ❄
    </div>
  );
};

export default function SnowEffect() {
  const [snowflakes, setSnowflakes] = useState<React.CSSProperties[]>([]);
  
  useEffect(() => {
    // Generate initial snowflakes
    const initialSnowflakes = Array.from({ length: 50 }, () => createSnowflakeStyle());
    setSnowflakes(initialSnowflakes);
    
    // Add new snowflakes periodically
    const interval = setInterval(() => {
      setSnowflakes(prev => {
        // Remove some old snowflakes to keep performance smooth
        if (prev.length > 100) {
          return [...prev.slice(-80), createSnowflakeStyle()];
        }
        return [...prev, createSnowflakeStyle()];
      });
    }, 500);
    
    return () => clearInterval(interval);
  }, []);
  
  // Create random snowflake style
  const createSnowflakeStyle = (): React.CSSProperties => {
    const size = Math.random() * 16 + 8; // Size between 8-24px
    const blur = Math.random() > 0.8; // Some snowflakes are blurry
    const left = Math.random() * 100; // Random horizontal position
    const animationDuration = Math.random() * 5 + 8; // Between 8-13s
    const animationDelay = Math.random() * 5; // Delay between 0-5s
    const type = Math.floor(Math.random() * 3) + 1; // 3 animation types
    
    return {
      fontSize: `${size}px`,
      left: `${left}vw`,
      filter: blur ? 'blur(1px)' : 'none',
      opacity: Math.random() * 0.8 + 0.2,
      animation: `snow-fall-${type} ${animationDuration}s linear ${animationDelay}s infinite`,
    };
  };
  
  return (
    <div className="snowflake-container">
      {snowflakes.map((style, index) => (
        <Snowflake key={index} style={style} />
      ))}
    </div>
  );
}