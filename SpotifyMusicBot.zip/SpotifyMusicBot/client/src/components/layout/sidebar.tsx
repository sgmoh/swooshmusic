import { useQuery } from "@tanstack/react-query";

// Define the structure of our bot status
interface BotStatus {
  isOnline: boolean;
  uptime: string;
  serverCount: number;
  id?: string;
  startupTime?: Date;
  lastUpdated?: Date;
}

interface SidebarProps {
  botStatus?: BotStatus | null | undefined;
}

export default function Sidebar({ botStatus }: SidebarProps) {
  // Fetch bot status if not provided
  const { data: fetchedStatus } = useQuery<BotStatus>({
    queryKey: ['/api/status'],
    enabled: !botStatus,
  });
  
  const status = botStatus || fetchedStatus;
  
  return (
    <nav className="w-full md:w-64 bg-discord-black border-r border-gray-800 md:min-h-screen p-4 flex flex-col relative z-10">
      {/* Snow on sidebar */}
      <div className="absolute top-0 right-0 p-2 opacity-30 text-2xl">❄</div>
      <div className="absolute top-20 right-4 p-2 opacity-20 text-xl">❄</div>
      <div className="absolute bottom-20 right-6 p-2 opacity-30 text-lg">❄</div>
      
      <div className="flex items-center mb-10">
        <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mr-3 glow">
          <i className="ri-music-2-fill text-2xl"></i>
        </div>
        <div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent">SWOOSH Music</h1>
          <p className="text-xs text-discord-light">Winter Edition</p>
        </div>
      </div>
      
      {/* Bot Info Panel */}
      <div className="mb-6 px-4 py-3 rounded-md bg-gradient-to-r from-discord-darker to-black border border-gray-800">
        <div className="flex items-center mb-3">
          <div className={`w-3 h-3 rounded-full ${status?.isOnline ? 'bg-status-online animate-pulse' : 'bg-status-dnd'} mr-2`}></div>
          <span className="font-medium">{status?.isOnline ? 'Bot Online' : 'Bot Offline'}</span>
        </div>
        <div className="text-sm text-discord-light space-y-2">
          <div className="flex items-center">
            <i className="ri-time-line mr-2"></i>
            <span>Uptime: {status?.uptime || 'Calculating...'}</span>
          </div>
          <div className="flex items-center">
            <i className="ri-server-line mr-2"></i>
            <span>Servers: {status?.serverCount || 0}</span>
          </div>
        </div>
      </div>
      
      {/* Invite Button */}
      <a 
        href="https://discord.com/oauth2/authorize?client_id=1361684972163039312&scope=bot&permissions=8" 
        target="_blank" 
        className="mb-8 text-center py-3 px-4 rounded-md bg-discord-blurple hover:bg-blue-600 transition flex items-center justify-center glow"
      >
        <i className="ri-add-line mr-2"></i>
        <span>Invite Bot to Server</span>
      </a>
      
      {/* Simple Nav */}
      <div className="space-y-1 mb-6">
        <h3 className="px-4 text-xs uppercase text-discord-light font-semibold tracking-wider mb-2">Bot Controls</h3>
        <a href="#music" className="flex items-center px-4 py-2 rounded-md text-white hover:bg-discord-darker transition">
          <i className="ri-music-2-line mr-3"></i>
          <span>Now Playing</span>
        </a>
        <a href="#commands" className="flex items-center px-4 py-2 rounded-md text-white hover:bg-discord-darker transition">
          <i className="ri-command-line mr-3"></i>
          <span>Commands</span>
        </a>
      </div>
      
      {/* Bot Stats */}
      <div className="mt-auto">
        <h3 className="px-4 text-xs uppercase text-discord-light font-semibold tracking-wider mb-2">Live Stats</h3>
        <div className="px-4 py-1 mb-1 text-xs text-discord-light flex items-center">
          <i className="ri-mic-line mr-2"></i>
          <span>ID: 1361684972163039312</span>
        </div>
        <div className="px-4 py-1 mb-1 text-xs text-discord-light flex items-center">
          <i className="ri-cloud-line mr-2"></i>
          <span>Winter Mode: Active</span>
        </div>
      </div>
    </nav>
  );
}
