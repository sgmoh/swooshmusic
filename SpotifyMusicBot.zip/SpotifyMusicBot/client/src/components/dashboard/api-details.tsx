import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";

export default function ApiDetails() {
  const { data: apiStatus, isLoading } = useQuery({
    queryKey: ['/api/api-status'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });
  
  if (isLoading) {
    return (
      <Card className="bg-discord-darkbg border-none text-white mb-8">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">API Status</h3>
            <div className="animate-pulse w-20 h-5 bg-discord-darker rounded"></div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="animate-pulse bg-discord-darker p-4 rounded-md h-32"></div>
            <div className="animate-pulse bg-discord-darker p-4 rounded-md h-32"></div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!apiStatus) {
    return (
      <Card className="bg-discord-darkbg border-none text-white mb-8">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">API Status</h3>
          </div>
          <p className="text-discord-light">Failed to load API status information</p>
        </CardContent>
      </Card>
    );
  }
  
  const { discord, spotify } = apiStatus;
  
  const getStatusColorClass = (status: number) => {
    if (!status) return 'bg-status-dnd text-status-dnd';
    if (status >= 200 && status < 300) return 'bg-status-online text-status-online';
    if (status >= 400 && status < 500) return 'bg-status-idle text-status-idle';
    return 'bg-status-dnd text-status-dnd';
  };
  
  return (
    <Card className="bg-discord-darkbg border-none text-white mb-8">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">API Status</h3>
          <div className="flex items-center space-x-2">
            <div className="flex items-center">
              <div className={`w-2 h-2 rounded-full ${discord?.lastStatus >= 200 && discord?.lastStatus < 300 ? 'bg-status-online' : 'bg-status-dnd'} mr-1`}></div>
              <span className="text-sm">Discord</span>
            </div>
            <div className="flex items-center">
              <div className={`w-2 h-2 rounded-full ${spotify?.lastStatus >= 200 && spotify?.lastStatus < 300 ? 'bg-status-online' : 'bg-status-dnd'} mr-1`}></div>
              <span className="text-sm">Spotify</span>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="bg-discord-darker p-4 rounded-md">
            <h4 className="text-sm font-medium mb-2 text-discord-light">Discord API</h4>
            <div className="text-xs text-discord-light space-y-1">
              <div className="flex justify-between">
                <span>Request Limit:</span>
                <span>{discord?.requestCount || 0}/{discord?.requestLimit || 0}</span>
              </div>
              <div className="flex justify-between">
                <span>Rate Limit Reset:</span>
                <span>{discord?.resetTimeFormatted || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span>Last Request Status:</span>
                <span className={getStatusColorClass(discord?.lastStatus)}>
                  {discord?.lastStatus || 'N/A'} {discord?.lastStatus >= 200 && discord?.lastStatus < 300 ? 'OK' : 'Error'}
                </span>
              </div>
            </div>
          </div>
          
          <div className="bg-discord-darker p-4 rounded-md">
            <h4 className="text-sm font-medium mb-2 text-discord-light">Spotify API</h4>
            <div className="text-xs text-discord-light space-y-1">
              <div className="flex justify-between">
                <span>Request Limit:</span>
                <span>{spotify?.requestCount || 0}/{spotify?.requestLimit || 0}</span>
              </div>
              <div className="flex justify-between">
                <span>Rate Limit Reset:</span>
                <span>{spotify?.resetTimeFormatted || 'N/A'}</span>
              </div>
              <div className="flex justify-between">
                <span>Last Request Status:</span>
                <span className={getStatusColorClass(spotify?.lastStatus)}>
                  {spotify?.lastStatus || 'N/A'} {spotify?.lastStatus >= 200 && spotify?.lastStatus < 300 ? 'OK' : 'Error'}
                </span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
