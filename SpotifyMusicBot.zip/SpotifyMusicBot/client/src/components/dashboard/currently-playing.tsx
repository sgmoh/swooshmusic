import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { useState, useEffect } from "react";

// Define the TrackData interface for type safety
interface TrackData {
  id: number;
  trackName: string;
  artistName: string;
  albumName: string;
  albumArt?: string;
  duration: number;
  progress?: number;
  progressPercent: number;
  server: string;
  channel: string;
  startedAt: string;
  isPlaying: boolean;
  formattedProgress: string;
  formattedDuration: string;
}

export default function CurrentlyPlaying() {
  const { data: track, isLoading } = useQuery<TrackData>({
    queryKey: ['/api/playing'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });
  
  const [progress, setProgress] = useState(0);
  
  // Update progress in real-time
  useEffect(() => {
    if (!track || !track.isPlaying) {
      setProgress(track?.progressPercent || 0);
      return;
    }
    
    setProgress(track.progressPercent);
    
    const interval = setInterval(() => {
      setProgress((prev) => {
        const newProgress = prev + (100 / (track.duration / 1000)) * 0.5;
        return Math.min(newProgress, 100);
      });
    }, 500);
    
    return () => clearInterval(interval);
  }, [track]);
  
  if (isLoading) {
    return (
      <Card className="bg-gradient-to-r from-discord-black to-discord-darker border border-gray-800 text-white mb-8 shadow-lg">
        <CardContent className="p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Currently Playing</h3>
            <div className="flex items-center">
              <i className="ri-spotify-fill text-spotify-green mr-2"></i>
              <span className="text-sm">Spotify</span>
            </div>
          </div>
          <div className="animate-pulse flex flex-col md:flex-row items-center">
            <div className="w-full md:w-40 h-40 bg-discord-darker rounded-md mr-0 md:mr-6 mb-4 md:mb-0 border border-gray-800"></div>
            <div className="flex-1 w-full space-y-4">
              <div className="h-6 bg-discord-darker rounded w-3/4"></div>
              <div className="h-4 bg-discord-darker rounded w-1/2"></div>
              <div className="h-2 bg-discord-darker rounded w-full mt-4"></div>
              <div className="flex justify-between">
                <div className="h-3 bg-discord-darker rounded w-10"></div>
                <div className="h-3 bg-discord-darker rounded w-10"></div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!track) {
    return (
      <Card className="bg-gradient-to-r from-discord-black to-discord-darker border border-gray-800 text-white mb-8 shadow-lg">
        <CardContent className="p-6 relative">
          {/* Add snowflakes for decoration when not playing */}
          <div className="absolute top-2 right-8 opacity-20 text-xl">❄</div>
          <div className="absolute bottom-8 left-12 opacity-30 text-lg">❄</div>
          
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Currently Playing</h3>
            <div className="flex items-center">
              <i className="ri-spotify-fill text-spotify-green mr-2"></i>
              <span className="text-sm">Spotify</span>
            </div>
          </div>
          <div className="flex flex-col items-center justify-center py-12 px-4">
            <i className="ri-music-2-line text-4xl text-discord-light mb-4 opacity-50"></i>
            <p className="text-discord-light text-center">No music is currently playing. Use <span className="font-mono bg-discord-darkbg px-1 py-0.5 rounded">.music play</span> to start listening!</p>
          </div>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-gradient-to-r from-discord-black to-discord-darker border border-gray-800 text-white mb-8 shadow-lg spotify-glow">
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg font-medium">Currently Playing</h3>
          <div className="flex items-center">
            <i className="ri-spotify-fill text-spotify-green mr-2"></i>
            <span className="text-sm">Spotify</span>
          </div>
        </div>
        
        <div className="flex flex-col md:flex-row items-center">
          <div className="w-full md:w-40 h-40 bg-discord-darker rounded-md mr-0 md:mr-6 mb-4 md:mb-0 flex-shrink-0 overflow-hidden border border-gray-800">
            {track.albumArt && (
              <img src={track.albumArt} alt="Album cover" className="w-full h-full object-cover" />
            )}
          </div>
          
          <div className="flex-1 w-full">
            <h4 className="text-xl font-semibold mb-1 bg-gradient-to-r from-white to-blue-200 bg-clip-text text-transparent">{track.trackName}</h4>
            <p className="text-discord-light mb-4">{track.artistName} • {track.albumName}</p>
            
            <div className="mb-2">
              <div className="spotify-progress h-1 bg-discord-darkbg rounded-sm mb-1 overflow-hidden">
                <div 
                  className="h-full bg-gradient-to-r from-spotify-green to-blue-500 rounded-sm" 
                  style={{ width: `${progress}%` }}
                ></div>
              </div>
              <div className="flex justify-between text-xs text-discord-light">
                <span>{track.formattedProgress}</span>
                <span>{track.formattedDuration}</span>
              </div>
            </div>
            
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center">
                <button className="text-2xl text-white hover:text-spotify-green mr-4" aria-label="Previous track">
                  <i className="ri-skip-back-fill"></i>
                </button>
                <button className="text-2xl text-white hover:text-spotify-green mr-4" aria-label={track.isPlaying ? "Pause" : "Play"}>
                  <i className={track.isPlaying ? "ri-pause-fill" : "ri-play-fill"}></i>
                </button>
                <button className="text-2xl text-white hover:text-spotify-green" aria-label="Next track">
                  <i className="ri-skip-forward-fill"></i>
                </button>
              </div>
              
              <div className="flex items-center">
                <span className="bg-gradient-to-r from-blue-600 to-blue-500 text-white text-xs px-2 py-1 rounded-full flex items-center">
                  <i className="ri-volume-up-line mr-1"></i>
                  <span>Playing in Voice Channel: {track.server} / {track.channel}</span>
                </span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
