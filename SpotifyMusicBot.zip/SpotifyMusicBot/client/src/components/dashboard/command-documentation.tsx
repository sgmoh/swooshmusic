import { Card, CardContent } from "@/components/ui/card";

export default function CommandDocumentation() {
  return (
    <Card className="bg-discord-black border border-gray-800 text-white mb-8 shadow-lg">
      <CardContent className="p-6 relative">
        {/* Add snowflakes for decoration */}
        <div className="absolute top-4 right-12 opacity-10 text-sm">❄</div>
        <div className="absolute bottom-12 left-20 opacity-10 text-sm">❄</div>
        
        <h3 className="text-lg font-medium mb-4 flex items-center">
          <i className="ri-terminal-box-line mr-2 text-discord-blurple"></i>
          Bot Commands
        </h3>
        
        <div className="space-y-4">
          <div>
            <div className="flex items-center mb-2">
              <span className="font-medium text-discord-blurple">.music search</span>
              <span className="text-sm text-discord-light ml-2">- Search for songs on Spotify</span>
            </div>
            <div className="font-mono text-sm border-none rounded-md bg-discord-darker p-3 overflow-x-auto">
              <span className="text-discord-blurple">.music search</span> <span className="text-yellow-400">song_name</span>
            </div>
          </div>
          
          <div>
            <div className="flex flex-wrap items-center mb-2">
              <span className="font-medium text-discord-blurple">.music play</span>
              <span className="text-sm text-discord-light ml-2">- Play a song in your voice channel</span>
              <span className="ml-2 px-1.5 py-0.5 text-xs bg-blue-700 text-white rounded-full">Requires voice</span>
            </div>
            <div className="font-mono text-sm border-none rounded-md bg-discord-darker p-3 overflow-x-auto">
              <span className="text-discord-blurple">.music play</span> <span className="text-yellow-400">song_name</span> <span className="text-gray-400">or</span> <span className="text-green-400">spotify_url</span>
            </div>
            <p className="text-xs text-discord-light mt-1 ml-1"><i className="ri-information-line mr-1"></i> You must be in a voice channel to use this command</p>
          </div>
          
          <div>
            <div className="flex items-center mb-2">
              <span className="font-medium text-discord-blurple">.music queue</span>
              <span className="text-sm text-discord-light ml-2">- View current song queue</span>
            </div>
            <div className="font-mono text-sm border-none rounded-md bg-discord-darker p-3 overflow-x-auto">
              <span className="text-discord-blurple">.music queue</span>
            </div>
          </div>
          
          <div>
            <div className="flex flex-wrap items-center mb-2">
              <span className="font-medium text-discord-blurple">.music controls</span>
              <span className="text-sm text-discord-light ml-2">- Control voice channel playback</span>
              <span className="ml-2 px-1.5 py-0.5 text-xs bg-blue-700 text-white rounded-full">Requires voice</span>
            </div>
            <div className="font-mono text-sm border-none rounded-md bg-discord-darker p-3 overflow-x-auto">
              <span className="text-discord-blurple">.music controls</span> <span className="text-yellow-400">pause|resume|skip|stop</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
