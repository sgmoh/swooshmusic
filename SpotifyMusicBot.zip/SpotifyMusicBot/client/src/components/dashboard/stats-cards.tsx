import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";

export default function StatsCards() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/stats'],
  });
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
      <Card className="bg-discord-darkbg border-none text-white">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Servers</h3>
            <i className="ri-server-line text-xl text-discord-blurple"></i>
          </div>
          {isLoading ? (
            <div className="h-12 animate-pulse bg-discord-darker rounded"></div>
          ) : (
            <>
              <p className="text-3xl font-semibold">{stats?.serverCount || 0}</p>
              <p className="text-sm text-discord-light mt-1">Bot Communities</p>
            </>
          )}
        </CardContent>
      </Card>
      
      <Card className="bg-discord-darkbg border-none text-white">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Commands Used</h3>
            <i className="ri-command-line text-xl text-discord-blurple"></i>
          </div>
          {isLoading ? (
            <div className="h-12 animate-pulse bg-discord-darker rounded"></div>
          ) : (
            <>
              <p className="text-3xl font-semibold">{stats?.commandsLast7Days || 0}</p>
              <p className="text-sm text-discord-light mt-1">Last 7 days</p>
            </>
          )}
        </CardContent>
      </Card>
      
      <Card className="bg-discord-darkbg border-none text-white">
        <CardContent className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-medium">Active Users</h3>
            <i className="ri-user-line text-xl text-discord-blurple"></i>
          </div>
          {isLoading ? (
            <div className="h-12 animate-pulse bg-discord-darker rounded"></div>
          ) : (
            <>
              <p className="text-3xl font-semibold">{stats?.uniqueUsers || 0}</p>
              <p className="text-sm text-discord-light mt-1">Unique users today</p>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
