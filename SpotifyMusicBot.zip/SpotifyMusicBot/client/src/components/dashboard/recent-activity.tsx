import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";

export default function RecentActivity() {
  const { data: activities, isLoading } = useQuery({
    queryKey: ['/api/commands'],
    refetchInterval: 10000, // Refresh every 10 seconds
  });
  
  if (isLoading) {
    return (
      <Card className="bg-discord-darkbg border-none text-white">
        <CardContent className="p-6">
          <h3 className="text-lg font-medium mb-4">Recent Activity</h3>
          <div className="animate-pulse space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="h-12 bg-discord-darker rounded"></div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }
  
  if (!activities || activities.length === 0) {
    return (
      <Card className="bg-discord-darkbg border-none text-white">
        <CardContent className="p-6">
          <h3 className="text-lg font-medium mb-4">Recent Activity</h3>
          <p className="text-discord-light text-center py-8">No recent activity found</p>
        </CardContent>
      </Card>
    );
  }
  
  return (
    <Card className="bg-discord-darkbg border-none text-white">
      <CardContent className="p-6">
        <h3 className="text-lg font-medium mb-4">Recent Activity</h3>
        
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="text-left text-discord-light text-sm border-b border-discord-darker">
                <th className="pb-3 font-medium">Time</th>
                <th className="pb-3 font-medium">Server</th>
                <th className="pb-3 font-medium">Command</th>
                <th className="pb-3 font-medium">Status</th>
              </tr>
            </thead>
            <tbody>
              {activities.map((activity, index) => (
                <tr key={index} className="border-b border-discord-darker">
                  <td className="py-3 text-sm">
                    <div className="text-white">{activity.relativeTime}</div>
                    <div className="text-xs text-discord-light">{activity.formattedTime}</div>
                  </td>
                  <td className="py-3 text-sm">{activity.server}</td>
                  <td className="py-3 text-sm font-mono">{activity.command}</td>
                  <td className="py-3 text-sm">
                    <span className={`px-2 py-0.5 ${activity.success ? 'bg-status-online bg-opacity-20 text-status-online' : 'bg-status-dnd bg-opacity-20 text-status-dnd'} rounded-full text-xs`}>
                      {activity.success ? 'Success' : 'Failed'}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        
        <div className="mt-4 text-sm text-center text-discord-light">
          <a href="#" className="text-discord-blurple hover:underline">View all activity →</a>
        </div>
      </CardContent>
    </Card>
  );
}
