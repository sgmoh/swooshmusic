import { useQuery } from "@tanstack/react-query";
import CurrentlyPlaying from "@/components/dashboard/currently-playing";
import RecentActivity from "@/components/dashboard/recent-activity";

// Define the BotStatus interface
interface BotStatus {
  isOnline: boolean;
  uptime: string;
  serverCount: number;
  id?: string;
  startupTime?: Date;
  lastUpdated?: Date;
}

export default function Dashboard() {
  // Fetch bot status
  const { data: botStatus } = useQuery<BotStatus>({
    queryKey: ['/api/status'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  return (
    <div className="min-h-screen bg-discord-black text-white font-sans relative z-10 py-10">
      {/* Snow effect overlay (visual only) */}
      <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
        <div className="absolute top-20 right-20 opacity-10 text-4xl">❄</div>
        <div className="absolute top-40 left-[10%] opacity-20 text-xl">❄</div>
        <div className="absolute bottom-20 right-[15%] opacity-15 text-3xl">❄</div>
        <div className="absolute bottom-40 left-30 opacity-10 text-2xl">❄</div>
      </div>
      
      {/* Main Content */}
      <main className="container mx-auto px-4 md:px-8 max-w-5xl">
        {/* Bot Status Header */}
        <div className="flex flex-col md:flex-row items-center justify-between mb-12 bg-discord-darker p-6 rounded-lg border border-gray-800 shadow-lg">
          <div className="mb-4 md:mb-0 text-center md:text-left">
            <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-purple-500 bg-clip-text text-transparent mb-2">
              SWOOSH Music Bot
            </h1>
            <p className="text-discord-light">Playing music in Discord voice channels</p>
          </div>
          
          <div className="flex flex-col items-center md:items-end">
            <div className="flex items-center mb-2">
              <span className={`w-3 h-3 rounded-full mr-2 ${botStatus?.isOnline ? 'bg-status-online' : 'bg-status-dnd'}`}></span>
              <span className="text-sm font-medium">{botStatus?.isOnline ? 'Online' : 'Offline'}</span>
            </div>
            {botStatus?.isOnline && (
              <>
                <div className="text-sm text-discord-light mb-1">Uptime: {botStatus.uptime}</div>
                <div className="text-sm text-discord-light">In {botStatus.serverCount} servers</div>
              </>
            )}
          </div>
        </div>
          
        {/* Currently Playing Section */}
        <div id="music" className="mb-10">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <i className="ri-spotify-fill text-spotify-green mr-2 text-2xl"></i>
            Now Playing
          </h3>
          <CurrentlyPlaying />
        </div>
          
        {/* Recent Activity */}
        <div id="activity" className="mb-12">
          <h3 className="text-xl font-semibold mb-4 flex items-center">
            <i className="ri-history-line mr-2 text-2xl"></i>
            Recent Activity
          </h3>
          <RecentActivity />
        </div>
          
        {/* Invite Button */}
        <div className="py-8 text-center mb-8">
          <a 
            href="https://discord.com/api/oauth2/authorize?client_id=1361684972163039312&permissions=8&scope=bot" 
            target="_blank" 
            rel="noopener noreferrer"
            className="inline-block px-10 py-4 rounded-full bg-gradient-to-r from-discord-blurple to-blue-600 hover:from-blue-600 hover:to-blue-700 transition-colors text-white font-bold text-lg shadow-lg"
          >
            <i className="ri-discord-fill mr-2"></i>
            Invite Bot to Your Server
          </a>
        </div>
        
        {/* Footer */}
        <div className="mt-8 mb-8 text-center">
          <div className="flex flex-col items-center">
            <div className="flex items-center mb-4">
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-600 flex items-center justify-center mr-3 glow">
                <i className="ri-music-2-fill text-xl"></i>
              </div>
              <h3 className="text-xl font-bold">SWOOSH Music</h3>
            </div>
            <p className="text-discord-light mb-2">A Discord music bot powered by Spotify</p>
            <p className="text-sm text-discord-light mt-2">Use <span className="font-mono bg-discord-darkbg px-1 py-0.5 rounded">.music play</span> in Discord to start listening!</p>
            <p className="text-xs text-discord-light mt-6">Cozy Winter Theme • Discord Music Bot</p>
          </div>
        </div>
      </main>
    </div>
  );
}
