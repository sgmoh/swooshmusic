# Spotify Music Bot

A Discord bot with a `.music` command that interfaces with Spotify's API, plus a website showing bot uptime and currently playing songs.

## Features

- Play music from Spotify in Discord voice channels
- Commands: `.music play`, `.music search`, `.music controls`, etc.
- Web dashboard showing bot status and currently playing tracks
- Automatic track searching and queue management

## Project Structure

This project consists of two main components:

1. **Node.js Web Dashboard**: Front-end website built with React, showing bot status and currently playing music
2. **Java Discord Bot**: Back-end bot using JDA and LavaPlayer for reliable audio playback

## Deployment Instructions

### Prerequisites

- Discord Bot Token
- Spotify API credentials (Client ID and Client Secret)
- [Render](https://render.com/) account

### Setup on Render

1. Create a new Web Service on Render
   - Connect your GitHub repository
   - Select "Docker" as the environment
   - Set the branch to "main"
   - Dockerfile path: `./Dockerfile`

2. Add Environment Variables:
   - `DISCORD_TOKEN`: Your Discord bot token
   - `SPOTIFY_CLIENT_ID`: Your Spotify client ID  
   - `SPOTIFY_CLIENT_SECRET`: Your Spotify client secret
   - `API_PORT`: Leave blank (Render will set this automatically)

3. Deploy the service

### Running Locally

1. Clone the repository
2. Create a `.env` file in the project root with your credentials:
   ```
   DISCORD_TOKEN=your_discord_bot_token
   SPOTIFY_CLIENT_ID=your_spotify_client_id
   SPOTIFY_CLIENT_SECRET=your_spotify_client_secret
   ```
3. Run the Node.js server:
   ```
   npm run dev
   ```
4. Build and run the Java Discord bot:
   ```
   cd java-discord-bot
   ./gradlew runBot
   ```

## Commands

- `.music play <song name or URL>` - Play a song from Spotify
- `.music search <query>` - Search for a song on Spotify
- `.music queue` - Show the current queue
- `.music controls pause|resume|skip|stop` - Control playback

## Web Dashboard

The dashboard shows:
- Bot uptime
- Connected servers
- Currently playing track
- Command history

## Tech Stack

- **Frontend**: React, Tailwind CSS, shadcn/ui
- **Backend**: Node.js, Express
- **Discord Bot**: Java, JDA, LavaPlayer
- **Database**: In-memory storage
- **APIs**: Discord API, Spotify Web API